import cma
import numpy as np
from utils.sampler import sample_box


class cma_optimizer:
    def __init__(self):
        pass

    def set_params(self, bounds, batch_size, num_rounds, seed):
        np.random.seed(seed)
        init_point = sample_box(1, bounds).squeeze()
        bdlist = [bounds[0].tolist(), bounds[1].tolist()]
        # recommendation derived from the CMA-ES docs
        sigma = np.mean(bounds[1]-bounds[0])/3.0
        self.es = cma.CMAEvolutionStrategy(init_point, sigma,
                                           {'popsize': batch_size,
                                            'bounds': bdlist,
                                            'seed': seed})

    def select_batch(self):
        candidates = self.es.ask()
        return np.vstack(candidates)

    def update(self, batch, function_values):
        self.es.tell(batch, function_values)

