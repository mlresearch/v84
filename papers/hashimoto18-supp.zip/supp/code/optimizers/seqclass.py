# multiplicative weights meta algorithm.
import numpy as np
from classifiers.linear import linear_classifier, quadratic_classifier
from classifiers.css import css_classifier
from classifiers.rbf import rbf_classifier
from classifiers.randforest import randforest_classifier
from classifiers.labelprop import labelprop_classifier
from classifiers.naivebayes import naivebayes_classifier
from classifiers.weightedforest import randforest_weighted_classifier, cv_randforest_weighted_classifier
from classifiers.ensembled_linear import ensembled_linear_classifier, cv_ensembled_linear_classifier
from utils.sampler import sample_box, sample_jitter
from math import log
import scipy.sparse
import scipy.sparse.linalg

def classifier_map(classifier_str, bounds):
    if classifier_str == 'auto':
        if (len(bounds[0]) > 200):
            classifier = linear_classifier(C=1.0)
        else:
            classifier = randforest_classifier()
    elif classifier_str == 'naive_bayes':
        classifier = naivebayes_classifier()
    elif classifier_str == 'aero':
        classifier = labelprop_classifier()
    elif classifier_str == 'ensembled_linear':
        classifier = ensembled_linear_classifier(eta=1.0, delta=2.0)
    elif classifier_str == 'css':
        classifier = css_classifier(lambda_=1e-5)
    elif classifier_str == 'linear':
        classifier = linear_classifier(C=1e-1)
    elif classifier_str == 'quadratic':
        classifier = quadratic_classifier(C=1.0, diag=True)
    elif classifier_str == 'rbf':
        classifier = rbf_classifier(C=1.0)
    elif classifier_str == 'randforest':
        classifier = randforest_classifier()
    elif classifier_str == 'weightedforest':
        classifier = randforest_weighted_classifier(eta=0.16, delta=1.9)
    elif classifier_str == 'cv_weightedforest':
        classifier = cv_randforest_weighted_classifier()
    else:
        raise Exception('no classifier named: '+classifier)
    return classifier
    


class base_classify_optimizer(object):
    def __init__(self, gamma=5.0, classifier_spec='auto'):
        self.gamma = gamma
        self.classifier_spec = classifier_spec
        self.classifier_list = []

    def _score_with_classifier(self, classifier, batch):
        evals = classifier.evaluate(batch)
        evals[np.isnan(evals)] = 1
        return evals

    def _score_cands(self, batch):
        score_vec = np.zeros(batch.shape[0])
        for classifier in self.classifier_list:
            score_vec += self._score_with_classifier(classifier, batch)
        return score_vec

    def _weighted_median(self, scores, weights, thresh):
        score_sort = np.argsort(scores)
        weight_sorted = weights[score_sort]
        inc_acc = np.cumsum(weight_sorted) / np.sum(weight_sorted)
        return scores[score_sort[np.argmax(inc_acc > thresh)]]

    def _get_weights(self, all=False):
        if all:
            weights = self.all_weights
        else:
            weights = self.weights

        prs = weights/np.sum(weights)
        return prs, weights

    def _train_classifier(self):
        classifier = self.classifier()
        prs, sample_weights = self._get_weights()
        cut_val = self._weighted_median(self.y_list, prs, 0.1)
        #cut_val_upper = self._weighted_median(self.y_list, prs, 0.2)
        #clen=float(len(self.classifier_list))+1
        #ysort = np.sort(np.unique(self.y_list))
        #mbs = min(self.batch_size, len(ysort))
        #cut_val = ysort[int(mbs*0.1)]
        self.cut_val = cut_val
        y_idx = self.y_list <= cut_val
        #y_use = self.y_list <= ysort[int(mbs-1)]
        pos_fraction, neg_count = classifier.train(self.x_list, 
                                                   y_idx, sample_weights)
        return classifier
        y_not_idx = self.y_list > cut_val
        idx_pos = np.random.choice(np.nonzero(y_idx)[0],
                                   5000,
                                   p=prs[y_idx]/np.sum(prs[y_idx]))
        idx_neg = np.random.choice(np.nonzero(y_not_idx)[0],
                                   5000,
                                   p=prs[y_not_idx]/np.sum(prs[y_not_idx]))
        idx = np.concatenate([idx_pos, idx_neg])
        weight = 1.0
        pos_fraction, neg_count = classifier.train(self.x_list[idx],
                                                   y_idx[idx])
        return classifier

    def update(self, batch, function_values):
        self._update_data(batch, function_values)
        new_classifier = self._train_classifier()
        self.classifier_list.append(new_classifier)
        self._update_weights(new_classifier)
        return [self.cut_val]

    def _update_data(self, batch, function_values):
        self.x_list = np.vstack([self.x_list, batch])
        self.y_list = np.concatenate([self.y_list, function_values])
        self.weights = np.concatenate([self.weights, np.ones(len(function_values))])


class continuous_classify_optimizer(base_classify_optimizer):
    def __init__(self, samp_count=200000, **kwargs):
        self.samp_count = samp_count
        super(continuous_classify_optimizer,
              self).__init__(**kwargs)

    def set_params(self, bounds, batch_size, num_rounds, seed):
        np.random.seed(seed)
        self.bounds = bounds
        self.batch_size = batch_size
        self.num_rounds = num_rounds
        self.x_list = np.zeros((0, len(self.bounds[0])))
        self.y_list = np.zeros(0)
        self.weights = np.zeros(0)
        self.prev_x = sample_box(self.batch_size, self.bounds)
        if isinstance(self.classifier_spec, str):
            self.classifier = lambda: classifier_map(self.classifier_spec, bounds)
        else:
            self.classifier = self.classifier_spec

    def select_batch(self):
        if len(self.classifier_list) == 0:
            return sample_box(self.batch_size, self.bounds)
        else:
            if len(self.bounds[0]) < 200:
                candidates = sample_jitter(self.prev_x, self.samp_count,
                                           self.bounds, 0.1)
            else:
                candidates = sample_jitter(self.prev_x, self.samp_count,
                                           self.bounds, 0.5)
            scores = self._score_cands(candidates)
            scores -= np.max(scores)
            prs = np.exp(self.gamma*scores)
            prs /= np.sum(prs)
            choice_id = np.random.choice(len(scores), self.batch_size,
                                         replace=False,
                                         p=prs)
            return candidates[choice_id]

    def _update_weights(self, new_classifier):
        total_weight_so_far = np.sum(self.weights)
        evals = self._score_with_classifier(new_classifier, self.x_list)
        self.weights *= np.exp(self.gamma * evals)
        new_total_weight = np.sum(self.weights)
        self.weights *= (total_weight_so_far / new_total_weight)

class discrete_classify_optimizer(base_classify_optimizer):
    def set_params(self, actions, batch_size, num_rounds, seed):
        np.random.seed(seed)
        self.actions = actions
        self.batch_size = batch_size
        self.num_rounds = num_rounds
        self.x_list = np.zeros((0, len(self.actions[0])))
        self.y_list = np.zeros(0)
        self.weights = np.zeros(0)
        self.all_weights = np.ones(self.actions.shape[0])
        self.act_counter = np.zeros(self.actions.shape[0])
        if isinstance(self.classifier_spec, str):
            self.classifier = lambda: classifier_map(self.classifier_spec, actions)
        else:
            self.classifier = self.classifier_spec

    def select_batch(self):
        if len(self.classifier_list) == 0:
            return self.actions[np.random.choice(
                len(self.actions), self.batch_size, replace=False)]
        else:
            candidates = self.actions
            prs, _ = self._get_weights(all=True)
            choice_id = np.random.choice(len(prs), self.batch_size,
                                         replace=False,
                                         p=prs)
            return candidates[choice_id]

    def _update_weights(self, new_classifier):
        total_weight_so_far = np.sum(self.all_weights)
        evals = self._score_with_classifier(new_classifier, self.x_list)
        self.weights *= np.exp(self.gamma * evals)

        evals = self._score_with_classifier(new_classifier, self.actions)
        self.all_weights *= np.exp(self.gamma * evals)

        new_total_weight = np.sum(self.all_weights)
        self.weights *= (total_weight_so_far / new_total_weight)
        self.all_weights *= (total_weight_so_far / new_total_weight)


class comparison_classify_optimizer(discrete_classify_optimizer):
    def __init__(self, factr=5, **kwargs):
        self.factr = factr
        super(comparison_classify_optimizer,
              self).__init__(**kwargs)
    
    def set_params(self, actions, batch_size, num_rounds, seed):
        discrete_classify_optimizer.set_params(
            self, actions, batch_size, num_rounds, seed)
        self.fn_val_list = np.zeros(0)
        self.comparisons_i = np.zeros(0).astype(int)
        self.comparisons_j = np.zeros(0).astype(int)
        self.comparison_value = np.zeros(0).astype(int)
 
    def _get_new_pairwise_comparisons(self, n_new):
        n = len(self.fn_val_list)
        d = min(self.factr, n)#int(log(n))
        if n - n_new > 0:
            d_old = int(log(n - n_new))
        else:
            d_old = 0

        p, _ = self._get_weights()
        probs = np.outer(p, p)
        probs[0:(n - n_new), 0:(n - n_new)] = 0
        probs = np.tril(probs, -1).reshape(-1)
        probs = probs / probs.sum()
        # probablt should be adding connections in the graph already seen, but for now just do new ones
        locs = np.random.choice(probs.shape[0], n_new * d, replace=False, p=probs)
        comparisons_i, comparisons_j = np.divmod(locs , n)
        comparison_value = np.take(self.fn_val_list, comparisons_i) >= np.take(self.fn_val_list, comparisons_j)
        return comparisons_i, comparisons_j, comparison_value

    def _rank_centrality(self, i, j, comparison, n, epsilon=0.05):
        """
        comparison is true if i is larger than j, false otherwise
        """
        comparison = np.array(comparison).astype(float)
        comparison = np.concatenate(((1 - epsilon) * comparison + epsilon * (1 - comparison),
                                     epsilon * comparison + (1 - epsilon) * (1 - comparison)))
        row = np.concatenate((i, j))
        col = np.concatenate((j, i))
        d_max = np.max(np.bincount(row))
        transition_prob = comparison / d_max
        transition_matrix = scipy.sparse.csr_matrix((transition_prob, (row, col)), shape=(n, n))
        transition_remains = transition_matrix.sum(axis=0)
        diag = 1 - np.asarray(transition_remains).reshape(-1)
        transition_matrix += scipy.sparse.diags(diag, 0)

        e,v = scipy.sparse.linalg.eigs(transition_matrix, k = 1)
        return (v.flatten() / v[0,0]).real

    def _update_data(self, batch, function_values):
        self.x_list = np.vstack([self.x_list, batch])
        self.fn_val_list = np.concatenate([self.fn_val_list, function_values])
        self.weights = np.concatenate([self.weights*0.0, np.ones(len(function_values))])

        
        votes = np.random.uniform(0,0.1,len(self.fn_val_list))
        references = np.random.choice(len(self.fn_val_list), self.factr)
        for i in range(len(references)):
            votes += self.fn_val_list > self.fn_val_list[references[i]]
        self.y_list = votes
        """
        new_comparisons_i, new_comparisons_j, comparison_value = self._get_new_pairwise_comparisons(
            len(function_values))
        self.comparisons_i = np.concatenate((self.comparisons_i, new_comparisons_i))
        self.comparisons_j = np.concatenate((self.comparisons_j, new_comparisons_j))
        self.comparison_value = np.concatenate([self.comparison_value, comparison_value])
        self.y_list = self._rank_centrality(self.comparisons_i, self.comparisons_j,
                                            self.comparison_value,
                                            len(self.fn_val_list))
        """


