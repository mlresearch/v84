# stub code, refactor / reimplement
import GPyOpt
import numpy as np
from utils.sampler import sample_box
from GPyOpt.models import GPModel
from GPyOpt.optimization import AcquisitionOptimizer
from GPyOpt.acquisitions.EI import AcquisitionEI
from GPyOpt.core.evaluators.batch_local_penalization import LocalPenalization


class gp_optimizer:
    def __init__(self, use_sparse=True, use_ei=True):
        self.use_sparse = use_sparse
        self.use_ei = use_ei

    def set_params(self, bounds, batch_size, num_rounds, seed):
        use_ei = self.use_ei
        use_sparse = self.use_sparse
        np.random.seed(seed)
        ndim = len(bounds[0])
        bdrange = [(bounds[0][i], bounds[1][i])
                   for i in range(len(bounds[0]))]
        cdom = GPyOpt.core.task.space.bounds_to_space(bdrange)
        self.space = GPyOpt.core.task.space.Design_space(cdom)
        if use_sparse:
            self.model = GPModel(optimize_restarts=2,
                                 verbose=False,
                                 sparse=True,
                                 exact_feval=True,
                                 max_iters=50,
                                 num_inducing=50)
        else:
            self.model = GPModel(optimize_restarts=2,
                                 verbose=False)
        acquisition_optimizer = AcquisitionOptimizer(self.space)
        ei_acq = AcquisitionEI(self.model, self.space,
                               optimizer=acquisition_optimizer)
        if use_ei:
            self.acquisition = ei_acq
            self.evaluator = GPyOpt.core.evaluators.batch_random.RandomBatch(
                self.acquisition, batch_size)
        else:
            # results in runtimes > 2hrs...
            self.acquisition = GPyOpt.acquisitions.LP.AcquisitionLP(
                self.model, self.space, acquisition_optimizer, ei_acq)
            self.evaluator = LocalPenalization(self.acquisition,
                                               batch_size, normalize_Y=True)
        self.xinit = sample_box(batch_size, bounds)
        self.bo = GPyOpt.core.bo.BO(self.model, self.space, lambda x: 0.0,
                                    self.acquisition, self.evaluator,
                                    self.xinit)
        self.x_history = np.zeros((0, ndim))
        self.y_history = np.zeros((0, 1))
        self.iter_id = 0

        

    def select_batch(self):
        self.iter_id += 1
        if self.iter_id == 1:
            return self.xinit
        else:
            return self.bo._compute_next_evaluations()

    def update(self, batch, function_values):
        self.x_history = np.vstack([self.x_history, batch])
        fv_vertical = np.array(function_values).reshape(
            (len(function_values), 1))
        self.y_history = np.vstack([self.y_history, fv_vertical])

        self.bo = GPyOpt.core.bo.BO(self.model, self.space, lambda x: 0.0,
                                    self.acquisition, self.evaluator,
                                    self.x_history, Y_init=self.y_history)
        self.bo.model_parameters_iterations = None
        self.bo.num_acquisitions = self.x_history.shape[0]
        self.bo.suggested_sample = self.bo.X
        self.bo.Y_new = self.bo.Y
        self.bo._update_model()


class discrete_gp_optimizer:
    def __init__(self, use_sparse=True, use_ei=True):
        self.use_sparse = use_sparse
        self.use_ei = use_ei

    def set_params(self, actions, batch_size ,num_rounds, seed):
        use_sparse = self.use_sparse
        use_ei = self.use_ei
        np.random.seed(seed)
        ndim = len(actions[0])
        self.actions = np.array(actions)
        domain = [{'name': 'actions', 'type': 'bandit', 'domain': actions}]
        self.space = GPyOpt.core.task.space.Design_space(domain)
        if use_sparse:
            self.model = GPModel(optimize_restarts=2,
                                 verbose=False,
                                 sparse=True,
                                 exact_feval=True,
                                 max_iters=50,
                                 num_inducing=100)
        else:
            self.model = GPModel(optimize_restarts=2,
                                 verbose=False)
        acquisition_optimizer = AcquisitionOptimizer(self.space)
        ei_acq = AcquisitionEI(self.model, self.space,
                               optimizer=acquisition_optimizer)
        if use_ei:
            self.acquisition = ei_acq
            self.evaluator = GPyOpt.core.evaluators.batch_random.RandomBatch(
                self.acquisition, batch_size)
        else:
            # enabling this option leads to per batch runtimes of > 10min on PBM
            self.acquisition = GPyOpt.acquisitions.LP.AcquisitionLP(
                self.model, self.space, acquisition_optimizer, ei_acq)
            self.evaluator = LocalPenalization(self.acquisition,
                                               batch_size, normalize_Y=True)
        self.xinit = np.array(actions)[np.random.choice(len(actions),
                                                        batch_size)]
        self.acquisition.optimizer.pulled_arms = self.xinit
        self.bo = GPyOpt.core.bo.BO(self.model, self.space, lambda x: 0.0,
                                    self.acquisition, self.evaluator,
                                    self.xinit)
        self.x_history = np.zeros((0, ndim))
        self.y_history = np.zeros((0, 1))
        self.iter_id = 0

    def select_batch(self):
        self.iter_id += 1
        if self.iter_id == 1:
            return self.xinit
        else:
            return self.bo._compute_next_evaluations()

    def update(self, batch, function_values):
        self.x_history = np.vstack([self.x_history, batch])
        fv_vertical = np.array(function_values).reshape(
            (len(function_values), 1))
        self.y_history = np.vstack([self.y_history, fv_vertical])
        self.acquisition.optimizer.pulled_arms = self.x_history
        self.bo = GPyOpt.core.bo.BO(self.model, self.space, lambda x: 0.0,
                                    self.acquisition, self.evaluator,
                                    self.x_history, Y_init=self.y_history)
        self.bo.model_parameters_iterations = None
        self.bo.num_acquisitions = self.x_history.shape[0]
        self.bo.suggested_sample = self.bo.X
        self.bo.Y_new = self.bo.Y
        self.bo._update_model()
