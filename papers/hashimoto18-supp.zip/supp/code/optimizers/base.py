from collections import namedtuple
import time
import numpy as np
from tqdm import trange
from scipy.optimize import minimize
from utils.sampler import sample_box


class iteration_log(namedtuple('iteration_log',
                               ['iter_id',
                                'eval_fvs', 'eval_points',
                                'batch_time', 'update_time',
                                'debug'])):
    __slots__ = ()

    def __str__(self):
        return str(self.iter_id) + ': fv:' + str(np.min(self.eval_fvs))\
            + ' time:' + str(self.eval_time) + ' debug:' + str(self.debug)


class abstract_optimizer:
    def __init__(self):
        """ instantiates an optimizer.
        """
        pass

    def select_batch(self):
        """ decide on what points to evaluate
        :return batch: numpy array of size batch_size X D
        """
        pass

    def update(self, batch, function_values):
        """ update the model based on observed function_values
        :param batch: numpy array of size batch_size X D
        :param function_values: numpy array of size
            batch_size with observed values
        :return debug: any debug messages to be stored in iteration_log
        """
        pass

    def set_params(self, bounds, batch_size, num_rounds, seed):
        """ sets the optimizer params:
        :param bounds: lower/upper optimization bounds. 
          for discrete methods this is the list of actions
        :param batch_size: number of samples to draw per round
        :param num_rounds: number of rounds to runt he optimizer
        :param seed: optional RNG seed
        """
class optimizer_wrapper:
    def __init__(self, base_optimizer, objective_function, 
                 batch_size, num_rounds, seed, **kwargs):
        """ instantiates a wrapper for base_optimizer
        all optimizers must have 
        .set_params(action / bounds, batch_size, num_rounds, seed) method,
        .select_batch()
        .update(batch, function_values)
        methods.
        discrete base_optimizers must also implement
        """
        self.num_rounds = num_rounds
        self.batch_size = batch_size
        self.objective_function = objective_function
        self.optimizer = base_optimizer
        if hasattr(objective_function, "bounds"):
            bounds = self.objective_function.bounds()
            self.optimizer.set_params(bounds, batch_size, num_rounds, seed)
        elif hasattr(objective_function, "actions"):
            actions = self.objective_function.actions()
            self.optimizer.set_params(actions, batch_size, num_rounds, seed)
        else:
            raise Exception('objective function specified is missing either a bounds or actions method')

    def run_all(self, debug_level=0):
        """ wrapper that checks batch size and tracks/logs outputs """
        iteration_log_list = []
        if debug_level == 0:
            rlist = range(self.num_rounds)
        else:
            rlist = trange(self.num_rounds)
        if debug_level == 2: # debug_level 2 is used ONLY to debug behavior of seqclass
            all_actions = self.objective_function.actions()
            all_values = self.objective_function.evaluate(all_actions)
            val_sort = np.argsort(all_values)
        for i in rlist:
            batch_select_start = time.time()
            batch = self.optimizer.select_batch()
            batch_select_end = time.time()
            batch_time = batch_select_end - batch_select_start
            assert batch.shape[0] == self.batch_size
            function_values = self.objective_function.evaluate(batch)
            update_start = time.time()
            debug = self.optimizer.update(batch, function_values)
            update_end = time.time()
            update_time = update_end - update_start
            it_log = iteration_log(iter_id=i,
                                   eval_fvs=function_values,
                                   eval_points=batch,
                                   batch_time=batch_time,
                                   update_time=update_time,
                                   debug=debug)
            if debug_level == 2:
                try:
                    all_score = self.optimizer._score_cands(all_actions[val_sort[0:5]])/float(i+1)
                    debug.append(all_score)
                except:
                    pass
            if debug_level > 0:
                rlist.set_postfix(iter_id=i,
                                  fv_min=np.min(function_values),
                                  batch_time=batch_time,
                                  update_time=update_time,
                                  debug=debug)
            iteration_log_list.append(it_log)
        return iteration_log_list


class random_optimizer:
    """ example optimizer that uniformly samples """
    def __init__(self):
        pass

    def set_params(self, bounds, batch_size, num_rounds, seed):
        self.bounds = bounds
        self.batch_size = batch_size
        np.random.seed(seed)

    def select_batch(self):
        return sample_box(self.batch_size, self.bounds)

    def update(self, batch, function_values):
        pass


class random_discrete_optimizer:
    def __init__(self):
        pass 

    def set_params(self, actions, batch_size, num_rounds, seed):
        self.actions = actions
        self.batch_size = batch_size
        np.random.seed(seed)

    def select_batch(self):
        return self.actions[np.random.choice(len(self.actions),
                                             self.batch_size)]

    def update(self, batch, function_values):
        pass
