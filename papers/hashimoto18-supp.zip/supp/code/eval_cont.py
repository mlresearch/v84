"""
Test / example code to check accuracy of the model.
"""

import matplotlib
matplotlib.use('Agg')
from functions.base import all_cont_functions
from optimizers.base import random_optimizer, optimizer_wrapper
from optimizers.cmaes import cma_optimizer
from optimizers.bayesopt import gp_optimizer
from optimizers.seqclass import continuous_classify_optimizer
from utils.plots import comparison_container
from utils.logger import logger

seed = 0
num_replicates = 5
opt_dict = {'random': random_optimizer, 'cma-es': cma_optimizer,
            'basic_classifier': continuous_classify_optimizer,
            'gp': gp_optimizer}

fun_list = all_cont_functions.keys()

log = logger()
for objname in fun_list:
    print('starting:'+objname)
    objfun = all_cont_functions[objname]()
    container = comparison_container(objname, 1)
    for opt_name in opt_dict.keys():
        print('method:'+opt_name)
        for seed in range(num_replicates):
            ropt = optimizer_wrapper(opt_dict[opt_name](),
                                     objfun, 1000, 10, seed)
            iterlog = ropt.run_all(debug_level=1)
            container.add_log(opt_name, iterlog)
    log.dump_container(container)
