import numpy as np
from sklearn.svm import LinearSVC
import theano.tensor as T
import theano
import simplex_projection
from tqdm import tqdm, trange
from sklearn import datasets


class unanimous_linear_classifier:
    def __init__(self, C=1e5):
        self.C = C
    
    def train_gamma(self, x, y, gamma):
        self.x = x
        self.y = y
        return self.train(x, y)
    
    def train(self, x, y):
        return 0, 0
    
    def eval_sub(self, xi, test_class, eps, verbose=False):
        xaug = np.vstack([self.x, xi])
        yaug = np.concatenate([self.y, test_class*np.ones(1)])
        svm = LinearSVC(C=self.C, tol=1e-10, random_state=0, loss='hinge',
                        intercept_scaling=1, verbose=verbose, max_iter=100000)
        svm.fit(xaug, yaug)
        return svm, svm.score(xaug, yaug)
    
    def evaluate(self, xnew, test_class=1, eps=1e-10):
        svm = LinearSVC(C=self.C, tol=1e-10, random_state=0, loss='hinge',
                        intercept_scaling=1, max_iter=100000)
        svm.fit(self.x, self.y)
        base_score = svm.score(self.x, self.y)
        zcall = []
        for xi in xnew:
            svm, score = self.eval_sub(xi, test_class, eps)
            if score > base_score-eps:
                zcall.append(test_class)
            else:
                zcall.append(1-test_class)
        return np.array(zcall)


def make_cone_fun():
    """
    theano function for optimizing:
    \sum (-1*AX^+)_+ \sum (-Y^+ \circ AX^-)
    :return: compiled theano function which takes
        parameters A, Y+, Y- and
        data X, X+ and returns gradients and loss
    """
    A = T.matrix('A')
    X = T.matrix('X')
    X_n = T.matrix('X_n')
    Y_neg = T.matrix('Y_neg')
    # loss for positive class - incur loss if any ax<0.
    ax = T.dot(X, A)
    pen_pos = T.sum(T.abs_(ax * (ax < 0)))
    # loss for negative class - incur loss selected by Y
    # ensure at least one axn < 0
    axn = T.dot(X_n, A)
    part_one = T.sum(Y_neg*axn, axis=1)
    pen_neg = T.sum(T.nnet.relu(part_one))
    tot_val = pen_pos + pen_neg
    tgrad = T.grad(tot_val, [A, Y_neg])
    run_cone = theano.function([A, X, X_n, Y_neg],
                               [pen_pos, pen_neg,
                                tgrad[0], tgrad[1]],
                               allow_input_downcast=True)
    return run_cone


def yproj(y):
    for i in range(y.shape[0]):
        y[i] = simplex_projection.euclidean_proj_simplex(y[i], 1)
    return y


def cut_linf(x):
    return x / np.max(np.abs(x), axis=1)[:, np.newaxis]


def run_cone(x_input, z_label, anum=3, alpha=0.001, niter=2000):
    x_proj = cut_linf(x_input)
    y_neg = yproj(np.ones((np.sum(z_label == 0), anum)))
    a_mat = np.random.normal(scale=0.001, size=(x_proj.shape[1], anum))
    for i in tqdm(range(niter), miniters=int(niter / 10)):
        alpha_eff = alpha / np.sqrt(i + 1)
        pos_pen, neg_pen, da, dy_neg = \
            run_cone_theano(a_mat, x_proj[z_label > 0], x_proj[z_label == 0],
                            y_neg)
        a_mat -= alpha_eff * da
        y_neg -= alpha_eff * dy_neg
        y_neg = yproj(y_neg)
    return a_mat


def make_one_class_cone_fun():
    """
    theano function for optimizing:
    \sum (Y^- \circ AX^-)
    :return: compiled theano function which takes
        parameters A, Y- and
        data X, and returns gradients and loss
    """
    A = T.matrix('A')
    X_n = T.matrix('X_n')
    Y_neg = T.matrix('Y_neg')
    sign = T.fscalar('sign')
    # loss for negative class - incur loss selected by Y
    # ensure at least one axn < 0
    axn = sign*T.dot(X_n, A)
    part_one = T.sum(Y_neg*axn, axis=1)
    pen_neg = T.sum(T.nnet.relu(part_one))
    tgrad = T.grad(pen_neg, [A, Y_neg])
    run_cone = theano.function([A, X_n, Y_neg, sign],
                               [pen_neg,
                                tgrad[0], tgrad[1]],
                               allow_input_downcast=True)
    return run_cone


run_one_cone_theano = make_one_class_cone_fun()


def make_hinge_class_loss():
    A = T.matrix('A')
    X = T.matrix('X')
    X_n = T.matrix('X_n')
    # hinge style_loss
    ax = T.dot(X, A)
    pen_pos = T.sum(T.abs_(ax * (ax < 0)))
    axn = T.dot(X_n, A)
    pen_neg = T.sum(T.abs_(axn * (axn > 0)))
    tgrad = T.grad(pen_neg + pen_pos, [A])
    run_cone = theano.function([A, X, X_n],
                               [pen_pos, pen_neg,
                                tgrad[0]],
                               allow_input_downcast=True)
    return run_cone


run_hinge_theano = make_hinge_class_loss()


def augment_data(x, scale=1.0):
    return np.hstack([x, np.ones((x.shape[0], 1))*scale])


def ymap(a_mat, x_unlabel):
    ax = np.dot(x_unlabel, a_mat)
    y_list = []
    for i in range(ax.shape[0]):
        tmp = np.zeros(ax.shape[1])
        tmp[np.argmin(ax[i])] = 1.0
        y_list.append(tmp)
    return np.array(y_list)


def a_init(x_input, anum, scale=1.0):
    from scipy.spatial import ConvexHull
    if x_input.shape[1] < 10:
        hull = ConvexHull(x_input)
        hull_normals = hull.equations[:, 0:(x_input.shape[1])]
        hull_offsets = hull.equations[:, (x_input.shape[1])]
        # invariant -
        # np.dot(x_input, np.transpose(hull_normals)) + hull_offsets < 0
        return np.vstack([np.transpose(hull_normals), hull_offsets/scale])
    else:
        return np.random.normal(scale=0.001, size=(x_input.shape[1]+1, anum))


def uncertain_cone(x_input, z_input, x_unlabel, target_label,
                   anum, scale=1.0, lamb=0.01, alpha=0.01, niter=2000):
    # x_proj = cut_linf(x_input)
    a_mat = a_init(x_input[:,:-1], anum, scale)
    anum = a_mat.shape[1]
    y_neg = yproj(np.ones((x_unlabel.shape[0], anum)))
    t = trange(niter, miniters=int(niter / 10))
    for i in t:
        alpha_eff = alpha / np.sqrt(i + 1)
        # non-cone loss
        pos_hinge, neg_hinge, da_hinge = \
            run_hinge_theano(a_mat, x_input[z_input > 0],
                             x_input[z_input == 0])
        a_mat -= alpha_eff * da_hinge
        # cone part.
        sign = 1.0
        if target_label != 1:
            sign = -1.0
        y_neg = (y_neg*0.5 + ymap(sign*a_mat, x_unlabel)*0.5)
        pen, da_cone, dy_neg = \
            run_one_cone_theano(a_mat, x_unlabel, y_neg, sign)
        a_mat -= alpha_eff * da_cone * lamb
        # y_neg -= alpha_eff * dy_neg * lamb 
        # y_neg = yproj(y_neg)
        y_inactive = np.sum(y_neg, axis=0) == 0
        a_mat[:, y_inactive] += np.random.randn(a_mat.shape[0],
                                                np.sum(y_inactive))*alpha_eff
        for j in range(a_mat.shape[1]):
            #if np.sum(a_mat[:, j]**2.0) > 1:
            a_mat[:, j] = a_mat[:, j] / np.sqrt(np.sum(a_mat[:, j]**2.0))
        t.set_postfix(hinge=pos_hinge+neg_hinge, pen=pen)
    return a_mat, y_neg, pos_hinge, neg_hinge, pen


run_cone_theano = make_cone_fun()

def unanimous_classification(train_set, train_label, test_set):
    uclass = unanimous_linear_classifier()
    uclass.train_gamma(train_set, train_label, 0)
    upos = uclass.evaluate(test_set, test_class=1, eps=1e-4)
    uneg = uclass.evaluate(test_set, test_class=0, eps=1e-4)
    upos[upos != uneg] = 2
    return upos

def unanimous_approx_via_cone(train_set, train_label, test_set, scale=5.0, niter=10000):
    factr = float(train_dat.shape[0])/float(test_dat.shape[0])
    a_mat, y_neg, pos_hinge, neg_hinge, pen = uncertain_cone(augment_data(train_set,scale), train_lab, augment_data(test_set,scale), 1, 10, scale, 0.01*factr, alpha=0.01, niter=niter)
    a_mat_2, y_neg_2, pos_hinge_2, neg_hinge_2, pen_2 = uncertain_cone(augment_data(train_dat, scale), train_lab, augment_data(test_set,scale), 0, 10, scale, 0.01*factr, alpha=0.01, niter=niter)
    sg1 = (np.min(np.dot(augment_data(test_set, scale),a_mat), axis=1) > 0).astype(int)
    sg2 = (np.max(np.dot(augment_data(test_set, scale),a_mat_2), axis=1) > 0).astype(int)
    sg1[sg1 != sg2] = 2
    return sg1, a_mat, a_mat_2, y_neg, y_neg_2


# Iris data

np.random.seed(1)
iris = datasets.load_iris()
shuf_ind = np.random.permutation(len(iris.target))
train_size = 10
train_dat = iris.data[shuf_ind[:train_size], :2]
train_lab = (iris.target > 0)[shuf_ind[:train_size]].astype(int)
test_dat = iris.data[shuf_ind[train_size:], :2]

upos = unanimous_classification(train_dat, train_lab, test_dat)

scale=5.0
upos_approx, amat, amat_2, y_neg, y_neg_2 = unanimous_approx_via_cone(train_dat, train_lab, test_dat)

import matplotlib as mpl
#mpl.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.lines as mlines

clist = np.array(['red','blue','green'])
plt.figure(figsize=(20,10))
plt.scatter(train_dat[:,0],train_dat[:,1],c=clist[train_lab], s=50)
plt.scatter(test_dat[:,0],test_dat[:,1],c=clist[upos], marker='2', alpha=0.5, s=50)
plt.savefig('test.png')
plt.close()

plt.figure(figsize=(20,10))
plt.scatter(train_dat[:,0],train_dat[:,1],c=clist[train_lab], s=50)
plt.scatter(test_dat[:,0],test_dat[:,1],c=clist[upos_approx], marker='2', alpha=0.5, s=50)
plt.savefig('test4.png')
plt.close()

def newline(beta_vec, color='blue', scale=100.0):
    ax = plt.gca()
    xmin, xmax = ax.get_xbound()
    p1 = (0, -1*scale*beta_vec[-1]/beta_vec[1])
    p2 = (-1*scale*beta_vec[-1]/beta_vec[0], 0)
    if(p2[0] == p1[0]):
        xmin = xmax = p1[0]
        ymin, ymax = ax.get_ybound()
    else:
        ymax = p1[1]+(p2[1]-p1[1])/(p2[0]-p1[0])*(xmax-p1[0])
        ymin = p1[1]+(p2[1]-p1[1])/(p2[0]-p1[0])*(xmin-p1[0])
    l = mlines.Line2D([xmin, xmax], [ymin, ymax], color=color)
    ax.add_line(l)
    return l

plt.figure(figsize=(20,10))
plt.scatter(train_dat[:,0],train_dat[:,1],c=clist[train_lab], s=50)
plt.scatter(test_dat[:,0],test_dat[:,1],c=clist[upos_approx], marker='2', alpha=0.5, s=50)

for i in np.nonzero(np.sum(y_neg,axis=0)>5.0)[0]:
    l = newline(amat[:,i], 'blue', scale)

for i in np.nonzero(np.sum(y_neg_2,axis=0)>5.0)[0]:
    l = newline(amat_2[:,i], 'red', scale)

plt.savefig('test3.png')
plt.close()


# other data
np.random.seed(1)
from sklearn.datasets import fetch_mldata
digits = fetch_mldata('USPS')

from sklearn.decomposition import PCA
valid_ids = np.concatenate([np.nonzero(digits.target==5)[0],np.nonzero(digits.target==6)[0]])
pca = PCA(n_components=50)
full_target = digits.target[valid_ids]
full_dat = pca.fit_transform(digits.data[valid_ids])

shuf_ind = np.random.permutation(len(full_target))
train_size = 800
test_size = 100
train_dat = full_dat[shuf_ind[:train_size],:]
train_lab = (full_target == full_target[0])[shuf_ind[:train_size]].astype(int)
test_dat = full_dat[shuf_ind[train_size:(train_size+test_size)], :]
test_lab = (full_target == full_target[0])[shuf_ind[train_size:(train_size+test_size)]].astype(int)

upos_usps = unanimous_classification(train_dat, train_lab, test_dat)

scale=5.0
upos_approx_usps, amat_usps, amat_2_usps, y_neg_usps, y_neg_2_usps = unanimous_approx_via_cone(train_dat, train_lab, test_dat, niter=20000)

held_dig_full = digits.data[valid_ids][shuf_ind[train_size:(train_size+test_size)]]


from matplotlib.backends.backend_pdf import PdfPages
pp = PdfPages('usps-test.pdf')
for i in np.argsort(upos_approx_usps):
    plt.figure(figsize=(20,10))
    plt.imshow(held_dig_full[i].reshape(16,16),cmap='Greys', interpolation='none')
    plt.title('real label:'+str(test_lab[i])+' pred_label:'+str(upos_approx_usps[i]))
    pp.savefig()

pp.close()
