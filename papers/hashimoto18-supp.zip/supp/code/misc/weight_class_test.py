import numpy as np


def logit(x):
    return 1.0/(1.0+np.exp(-x))


np.random.seed(0)
D = 5
w = np.random.randn(D)
wnorm = w/np.linalg.norm(w)*np.random.random(1)*10.0
N = 1000
x = np.random.randn(N, D)
z = logit(np.dot(x, wnorm))
y = np.random.binomial(1, z)

from sklearn.linear_model import LogisticRegression


def logloss(y,f):
    return np.log(1+np.exp(-2*(y-0.5)* f))

lr = LogisticRegression(C=1e10, max_iter=1000)
lr.fit(x, y)
lmin = np.sum(logloss(y, np.dot(x, lr.coef_.reshape(D)) + lr.intercept_))

llist = []
for i in range(1000):
    rc = np.random.choice(N, size=500, replace=True)
    lr = LogisticRegression(C=1e10, max_iter=1000)
    _ = lr.fit(x[rc], y[rc])
    ll = np.sum(logloss(y, np.dot(x, lr.coef_.reshape(D)) + lr.intercept_))
    llist.append(ll-lmin)

lweight = np.array(llist)**(-1*(D/2.0-1.0))
lresamp = np.random.choice(llist, size=1000, replace=True, p=lweight/np.sum(lweight))

import matplotlib as mpl
import matplotlib.pyplot as plt
import scipy.stats
plt.figure()
scipy.stats.probplot(lresamp, dist=scipy.stats.expon, plot = plt)
plt.figure()
scipy.stats.probplot(llist, dist=scipy.stats.chi2, sparams=(D), plot = plt)
plt.show()
