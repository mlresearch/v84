"""
Test / example code to check accuracy of the model.
"""

import matplotlib
matplotlib.use('Agg')
from functions.optfun import linear_objective
from optimizers.base import random_optimizer, optimizer_wrapper
from optimizers.bayesopt import gp_optimizer
from optimizers.seqclass import basic_classify_optimizer
from utils.plots import comparison_container
from utils.logger import logger

seed = 0
num_replicates = 5
opt_dict = {
#    'random': random_optimizer,
#    'linear_classifier': basic_classify_optimizer,
    'ensembled_linear_classifier': basic_classify_optimizer,
#    'gp': gp_optimizer
}

log = logger()
objname = "linear_objective"
print('starting:'+objname)
objfun = linear_objective()
container = comparison_container(objname, 1)
for opt_name in opt_dict.keys():
    print('method:'+opt_name)
    for seed in range(num_replicates):
        if opt_name == "ensembled_linear_classifier":
            ropt = optimizer_wrapper(opt_dict[opt_name](),
                                     objfun, 1000, 10, seed,
                                     classifier="cv_ensembled_linear")
        else:
            ropt = optimizer_wrapper(opt_dict[opt_name](),
                                     objfun, 1000, 10, seed)
        iterlog = ropt.run_all(debug_level=1)
        container.add_log(opt_name, iterlog)
log.dump_container(container)
