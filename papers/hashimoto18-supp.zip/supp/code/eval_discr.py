"""
Test / example code to check accuracy of the model.
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot
from functions.logistic_mnist import mnist_logistic_hyperparameter_experiment
from functions.PBM import pbm_experiment
from functions.aero import airfoil_discrete, Airfoil
from optimizers.base import random_discrete_optimizer, optimizer_wrapper
from optimizers.bayesopt import discrete_gp_optimizer
from optimizers.seqclass import discrete_classify_optimizer
from utils.plots import comparison_container
from utils.logger import logger

seed = 0
num_replicates = 5
opt_dict = {
    'random': random_discrete_optimizer,
    'gp': discrete_gp_optimizer,
    'discrete_classifier': discrete_classify_optimizer
}

###
# PBM

fun_list = [pbm_experiment]

log = logger()
for seed in range(10):
    objfun = pbm_experiment(seed)
    objname = 'pbm_experiment_'+objfun.pbm_name
    print('starting:'+objname)
    container = comparison_container(objname, 1)
    for opt_name in opt_dict.keys():
        print('method:'+opt_name)
        for seed in range(num_replicates):
            ropt = optimizer_wrapper(opt_dict[opt_name](),
                                     objfun, 1000, 10, seed)
            iterlog = ropt.run_all(debug_level=1)
            container.add_log(opt_name, iterlog)
    log.dump_container(container)

##
# airfoil experiments

log = logger()
print('starting: airfoil simulations')
objfun = airfoil_discrete()
container = comparison_container('airfoil', 1)
for opt_name in opt_dict.keys():
    print('method:'+opt_name)
    for seed in range(num_replicates):
        ropt = optimizer_wrapper(opt_dict[opt_name](),
                                 objfun, 20, 10, seed)
        iterlog = ropt.run_all(debug_level=1)
        container.add_log(opt_name, iterlog)
log.dump_container(container)

for opt_name in opt_dict.keys():
    iterlogs = container.method_logs[opt_name][0]
    lastlog = iterlogs[-1]
    minpoint = lastlog.eval_points[np.argmin(lastlog.eval_fvs)]
    best_airfoil = Airfoil(objfun.nx, minpoint)
    best_airfoil.set_freestream(1, 5.0)
    best_airfoil.simulate_airflow()
    best_airfoil.plot_all()
    pyplot.savefig(log.output_dir+'/'+opt_name+'_airfoil.png')


##
# Hyperparam opt
fun_list = [mnist_logistic_hyperparameter_experiment]

log = logger()
for seed in range(10):
    objfun = mnist_logistic_hyperparameter_experiment(seed)
    objname = "mnist_experiment_%s" % seed
    print(objfun.actions().shape)
    print('starting:'+objname)
    container = comparison_container(objname, 1)
    for opt_name in opt_dict.keys():
        print('method:'+opt_name)
        for seed in range(num_replicates):
            ropt = optimizer_wrapper(opt_dict[opt_name](),
                                     objfun, 1000, 10, seed)
            iterlog = ropt.run_all(debug_level=1)
            container.add_log(opt_name, iterlog)
    log.dump_container(container)

