# Benchmark code for optimization via classification

Overall interface - 
  * Functions are black-box, batch-evaluatable functions. 
  * Function boundaries are box-shaped
  * Classifiers must provide a fit function to minimize training error

## Code directory structure

Roughly, the planned code structure is below - 
(some of the functions may be missing for now).

### dataset - scripts to generate / store datasets
  * dataset.pbm.sh - generates dataset/PBM folder with the PBM experimental dataset for the PBM function.

### functions - contains test functions
  * functions.base - contains the interface and wrappers for all tests
  * functions.optfun - contains standard optimization benchmarks in 2-10D like Branin
  * functions.PBM - protein binding microarray real-world data based benchmark
  * functions.aero - airfoil optimization task
  * functions.reinforce - reinforcement learning benchmarks
  * functions.physics - physical simulation based benchmarks


### classifiers - contains base classifiers
  * classifiers.base - interface and wrappers to classifiers
  * classifiers.linear - linear optimization via SVM
  * classifiers.RBF - RBF based classification.
  * classifiers.randforest - random forest

### optimizers - contains optimization methods
  * optimizers.base - contains interface and wrapppers
  * optimizers.bayesopt - bayesian optimization baselines
  * optimizers.cmaes - CMA-ES based evolutionary baseline
  * optimizers.seqclass - sequential classification baseline.
  
### utils - contains shared utils and generic functions
  * utils.simplex_projection - projection onto L1 ball and simplex

## Testing

Use Pytest using the test_(FILENAME).py convention. Rely mostly on integration tests for hard tests.

For functions 
  * Test the functions at the extremes of the domains
  * Test the functions at batch values of of 1-100

For classifiers
  * Test the methods on iris

For optimizers
  * Run it on a low-dim linear objective to test.

