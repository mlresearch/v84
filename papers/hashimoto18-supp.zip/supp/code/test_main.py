"""
Test / example code to check accuracy of the model.
"""

import matplotlib
matplotlib.use('Agg')
from functions.base import all_cont_functions
from functions.PBM import pbm_experiment
from optimizers.base import random_optimizer, optimizer_wrapper, random_discrete_optimizer
from optimizers.cmaes import cma_optimizer
from optimizers.bayesopt import gp_optimizer, discrete_gp_optimizer
from optimizers.seqclass import continuous_classify_optimizer, discrete_classify_optimizer
from utils.plots import comparison_container
from utils.logger import logger

seed = 0
num_replicates = 2
opt_dict = {'random': random_optimizer, 'cma-es': cma_optimizer,
            'seq_classifier': continuous_classify_optimizer,
            'gp': gp_optimizer}

fun_list = all_cont_functions.keys()

log = logger()
for objname in fun_list:
    print('starting:'+objname)
    objfun = all_cont_functions[objname]()
    container = comparison_container(objname, 1)
    for opt_name in opt_dict.keys():
        print('method:'+opt_name)
        for seed in range(num_replicates):
            ropt = optimizer_wrapper(opt_dict[opt_name](),
                                     objfun, 100, 5, seed)
            iterlog = ropt.run_all(debug_level=1)
            container.add_log(opt_name, iterlog)
    log.dump_container(container)

opt_dict_discr = {
    'random': random_discrete_optimizer,
    'gp': discrete_gp_optimizer,
    'discrete_classifier': discrete_classify_optimizer,
}

fun_list = [pbm_experiment]

objfun = pbm_experiment(0)
objname = 'pbm_experiment_'+objfun.pbm_name
print('starting:'+objname)
container = comparison_container(objname, 1)
for opt_name in opt_dict_discr.keys():
    print('method:'+opt_name)
    for seed in range(num_replicates):
        ropt = optimizer_wrapper(opt_dict_discr[opt_name](),
                                 objfun, 100, 5, seed)
        iterlog = ropt.run_all(debug_level=1)
        container.add_log(opt_name, iterlog)
log.dump_container(container)

