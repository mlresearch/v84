import numpy as np
from classifiers.weightedforest import randforest_weighted_classifier


def quadrant_problem(n=500, d=10):
    X = np.random.randn(n, d)
    y = (X[:, 0:2] > 0).prod(axis=1)
    y = y.astype(int)
    return (X, y)


def test_quadrant():
    X_train, y_train = quadrant_problem(5000, 10)
    X_test, y_test = quadrant_problem(5000, 10)
    for eta in np.geomspace(0.00001, 20, 10):
        for delta in np.linspace(0.01, 2, 20):
            if eta * delta > 0.5:
                continue
            classifier = randforest_weighted_classifier(eta=eta, delta=delta)
            classifier.train(X_train, y_train)
            predictions = classifier.evaluate(X_test)
            print((eta, delta,
                   (y_test == (predictions > 0).astype(int)).mean()))

# test_quadrant()


def get_acc(y,pred):
    return (y == (pred > 0).astype(int)).mean()


np.random.seed(2)
X_train, y_train = quadrant_problem(50, 10)
X_test, y_test = quadrant_problem(5000, 10)
classifier = randforest_weighted_classifier(eta=0.0, delta=0.0)
classifier.train(X_train, y_train)
pred_base = classifier.rf.predict(X_test)
base_acc = get_acc(y_test, pred_base)
print(base_acc)
pred_list = []
eta_list = np.geomspace(0.0001, 50, 50)
for eta in eta_list:
    pred_list.append(classifier.evaluate(X_test, eta))


acc_list = [get_acc(y_test, subpred) for subpred in pred_list]

import matplotlib.pyplot as plt
plt.plot(eta_list, acc_list)
plt.plot(eta_list, np.ones(len(acc_list))*base_acc)
plt.show()

plt.hist(classifier.tree_losses, 20)
plt.show()
