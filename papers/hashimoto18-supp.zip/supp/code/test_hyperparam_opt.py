"""
Test / example code to check accuracy of the model.
"""

import matplotlib
matplotlib.use('Agg')
from functions.logistic_mnist import mnist_logistic_hyperparameter_experiment
from optimizers.base import random_discrete_optimizer, optimizer_wrapper
from optimizers.bayesopt import discrete_gp_optimizer
from optimizers.seqclass import discrete_classify_optimizer
from utils.plots import comparison_container
from utils.logger import logger

seed = 0
num_replicates = 5
opt_dict = {'random': random_discrete_optimizer,
            'gp': discrete_gp_optimizer,
            'discrete_classifier': discrete_classify_optimizer}

fun_list = [mnist_logistic_hyperparameter_experiment]

log = logger()
for seed in range(10):
    objfun = mnist_logistic_hyperparameter_experiment(seed)
    objname = "mnist_experiment_%s" % seed
    print(objfun.actions().shape)
    print('starting:'+objname)
    container = comparison_container(objname, 1)
    for opt_name in opt_dict.keys():
        print('method:'+opt_name)
        for seed in range(num_replicates):
            ropt = optimizer_wrapper(opt_dict[opt_name](),
                                     objfun, 1000, 10, seed)
            iterlog = ropt.run_all(debug_level=1)
            container.add_log(opt_name, iterlog)
    log.dump_container(container)

