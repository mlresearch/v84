from sklearn.semi_supervised import LabelSpreading
import numpy as np


class labelprop_classifier:
    def __init__(self):
        pass

    def train(self, x, y, weight=None):
        if weight is None:
            weight = np.ones(len(y))
        self.x_last = x
        self.xhash = dict([(str(x[i]), i) for i in range(len(y))])
        self.y_last = y
        return 0, 0

    def evaluate(self, x):
        lp = LabelSpreading(kernel='knn', n_neighbors=5)
        ynew = []
        for xi in x:
            if str(xi) in self.xhash:
                ynew.append(self.y_last[self.xhash[str(xi)]])
            else:
                ynew.append(-1)
        lp.fit(x, ynew)
        y_pred = lp.predict_proba(x)[:, 0]
        y_frac_old = np.mean(self.y_last)
        return y_pred < np.sort(y_pred)[int(len(y_pred)*y_frac_old)]
