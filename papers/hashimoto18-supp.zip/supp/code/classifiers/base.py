class abstract_classifier:
    def __init__():
        pass

    def train(self, x, y):
        """ if the classifier represents hypothesis class H
        train should fit \min_h E[L(y,h(x))] for some L
        may return any diagnostics
        (which will be ignored by any downstream optimizer)
        """

    def evaluate(self, x):
        """ make predictions on new points x."""
