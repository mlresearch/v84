import numpy as np
from sklearn.svm import SVC


class rbf_classifier:
    def __init__(self, C):
        """
        Example classifier using RBF-SVM.
        :param C: regularization constant for trading off errors and margin.
                  C -> infty is hard margin (allow no errors and max margin).
        """
        self.C = C

    def train(self, x, y, weight=1.0):
        class_weight = {1: 1.0, 0: weight}
        self.svm = SVC(C=self.C,
                       gamma=0.1,
                       kernel='rbf',
                       class_weight=class_weight)
        self.svm.fit(x, y)
        x_pred = self.svm.predict(x)
        pos_fraction = np.sum(x_pred == 1)/float(len(x_pred))
        neg_count = np.sum((x_pred == 0) * (y == 0))
        return pos_fraction, neg_count

    def evaluate(self, x):
        return self.svm.predict(x)
