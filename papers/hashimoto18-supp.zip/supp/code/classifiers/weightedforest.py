from sklearn.ensemble import RandomForestClassifier
import numpy as np
from numba import jit
from sklearn.model_selection import StratifiedKFold
from math import log

@jit
def calc_log_ratio(predictions, weights, eta, delta):
    empirical_log_ratio = np.zeros(predictions.shape[0])
    weight_sum = weights.sum()
    weight_of_positive = predictions.dot(weights)
    empirical_log_ratio[weight_of_positive == 0.0] = - delta - 1
    empirical_log_ratio[weight_of_positive == weight_sum] = delta + 1
    unset = empirical_log_ratio == 0.0
    empirical_log_ratio[unset] = (1 / float(eta)) * np.log(
        weight_of_positive[unset] / (weight_sum - weight_of_positive[unset]))
    return empirical_log_ratio

class randforest_weighted_classifier:
    def __init__(self, eta=1.0, delta=0.1):#, tau=3):
        """
        Random forest classifier
        """
        self.eta = eta
        self.delta = delta
        #self.tau = tau

    def train(self, x, y, weight=1.0):
        class_weight = {1: 1.0, 0: weight}
        self.rf = RandomForestClassifier(n_estimators=100, max_depth=8,
                                         class_weight=class_weight)
        self.rf.fit(x, y)
        self.tree_losses = 1 - np.array([dt.score(x, y) for dt in self.rf.estimators_])
        x_pred = self.rf.predict(x)
        pos_fraction = np.sum(x_pred == 1)/float(len(x_pred))
        neg_count = np.sum((x_pred == 0) * (y == 0))
        return pos_fraction, neg_count

    def evaluate(self, x, eta=None, delta=None, tau=None):
        if eta is None:
            eta = self.eta
        if delta is None:
            delta = self.delta
        # if tau is None:
        #     tau = self.tau

        weights = np.exp(-eta * self.tree_losses)# / np.power(tree_losses, self.tau)
        predictions = np.array([dt.predict(x) for dt in self.rf.estimators_]).T
        eta = eta if eta != 0.0 else 1.0
        empirical_log_ratio = calc_log_ratio(predictions, weights, eta, delta)
        use_prediction = (np.abs(empirical_log_ratio) >= delta).astype(int)
        prediction = (use_prediction * (empirical_log_ratio > 0)).astype(np.float)
        prediction[use_prediction == 0] = np.nan
        return prediction

class cv_randforest_weighted_classifier:
    def __init__(self):
        self.hyperparam_grid = np.array([
            [eta, delta]
            for eta in np.linspace(0, 8, 40)
            for delta in np.geomspace(1e-4, 0.1 + 2.0 / (eta + 1.0), 20)
        ])

    def train(self, x, y, weight=1.0, n_cv=10, n_hyperparams=40, epsilon=0.01):
        possible_hyperparameter_settings = self.hyperparam_grid.shape[0]
        hyperparam_candidates_idx = np.random.choice(
            possible_hyperparameter_settings, n_hyperparams, replace=False)
        hyperparam_candidates = self.hyperparam_grid[hyperparam_candidates_idx]

        kfold = StratifiedKFold(n_splits=n_cv)
        classifier = randforest_weighted_classifier()

        # it's like golf, low score is better
        scores = {(eta, delta): [] for eta, delta in hyperparam_candidates}
        coverage = {(eta, delta): [] for eta, delta in hyperparam_candidates}
        for train, test in kfold.split(x, y):
            X_train = x[train]
            y_train = y[train]
            X_test = x[test]
            y_test = y[test]
            classifier.train(X_train, y_train, weight=weight)
            for eta, delta in hyperparam_candidates:
                y_eval = classifier.evaluate(X_test, eta=eta, delta=delta)
                selection = np.logical_not(np.isnan(y_eval))
                err = (y_test[selection] != y_eval[selection]).mean()
                coverage[(eta, delta)].append(selection.mean())
                if (selection.sum() > 0):
                    scores[(eta, delta)].append(err)
        evaled_err = np.array([np.array(scores[hyperparameters]).mean() for hyperparameters in scores.keys()])
        evaled_coverage = np.array([np.array(coverage[hyperparameters]).mean() for hyperparameters in scores.keys()])

        evaled_etas = np.array([hyperparameters[0] for hyperparameters in scores.keys()])
        evaled_deltas = np.array([hyperparameters[1] for hyperparameters in scores.keys()])

        lowest_err = np.min(evaled_err)
        acceptable_hyperparams = evaled_err < lowest_err + epsilon
        useful_hyperparam = np.argmax(evaled_coverage[acceptable_hyperparams])

        self.delta = (evaled_deltas[acceptable_hyperparams])[useful_hyperparam]
        self.eta = (evaled_etas[acceptable_hyperparams])[useful_hyperparam]

        self.classifier = randforest_weighted_classifier(eta=self.eta, delta=self.delta)
        self.classifier.train(x, y)
        x_pred = self.classifier.evaluate(x)
        pos_fraction = np.sum(x_pred == 1)/float(len(x_pred))
        neg_count = np.sum((x_pred == 0) * (y == 0))
        return pos_fraction, neg_count

    def evaluate(self, x):
        return self.classifier.evaluate(x)
