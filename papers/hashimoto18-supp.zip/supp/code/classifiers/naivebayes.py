from sklearn.naive_bayes import BernoulliNB
from sklearn.ensemble import RandomForestClassifier
from functions.PBM import char_list
import numpy as np


class naivebayes_classifier:
    def __init__(self, alpha=100.0):
        self.alpha = alpha

    def make_dinuc(self, x):
        dnmat = np.zeros((x.shape[0], 16*7))
        for i in range(x.shape[0]):
            nzind = np.nonzero(x[i])[0]
            nzrel = nzind - np.arange(8)*4
            shift_idx = nzrel[:-1] + nzrel[1:]*4
            dnmat[i, shift_idx] = 1
        return dnmat

    def train(self, x, y, weight=None):
        if weight is None:
            weight = np.ones(len(y))
        #self.nb = BernoulliNB(alpha=self.alpha)
        #self.dinuc_nb = BernoulliNB(alpha=2*self.alpha)
        #self.nb.fit(x, y, weight)
        self.rf_base = RandomForestClassifier()
        self.rf_base.fit(x, y, weight)
        self.rf = RandomForestClassifier()
        self.rf.fit(self.make_dinuc(x), y, weight)
        self.y_last = y
        return 0, 0

    def evaluate(self, x):
        #p_pwm = self.nb.predict_proba(x)[:, 1]
        p1 = self.rf.predict_proba(self.make_dinuc(x))[:,1]
        #p2 = self.rf_base.predict_proba(x)[:,1]
        return p1 > 0.5 #(p1+p2)/2.0 > 0.5
