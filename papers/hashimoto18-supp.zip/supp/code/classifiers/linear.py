import numpy as np
from sklearn.linear_model import LogisticRegression


class linear_classifier:
    def __init__(self, C):
        """
        Example classifier using linear model.
        :param C: regularization constant for trading off errors and margin.
                  C -> infty is hard margin (allow no errors and max margin).
        """
        self.C = C

    def train(self, x, y, sample_weight=None):
        if sample_weight is None:
            sample_weight = np.ones(len(y))
        self.logit = LogisticRegression(C=self.C)
        self.logit.fit(x, y, sample_weight)
        x_pred = self.logit.predict(x)
        pos_fraction = np.sum(x_pred == 1)/float(len(x_pred))
        neg_count = np.sum((x_pred == 0) * (y == 0))
        return pos_fraction, neg_count

    def evaluate(self, x):
        return self.logit.predict(x)


class quadratic_classifier:
    def __init__(self, C, diag):
        """
        Classifier for quadratic decision boundaries
        :param C: regularization cosntant
        :param diag: use diagonal (ie axis aligned)
            ellipses.
        """
        self.linear_classifier = linear_classifier(C)
        self.C = C
        self.diag = diag

    def map_x(self, x):
        if self.diag:
            xnew = np.hstack([x, x**2.0])
        else:
            xquad = []
            for i in range(x.shape[0]):
                xquad.append(np.outer(x[i], x[i]).flatten())
            xquad = np.array(xquad)
            xnew = np.hstack([x, xquad])
        return xnew

    def train(self, x, y, weight=1.0):
        return self.linear_classifier.train(self.map_x(x), y, weight)

    def evaluate(self, x):
        return self.linear_classifier.evaluate(self.map_x(x))
