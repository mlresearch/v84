from sklearn.ensemble import BaggingClassifier
from sklearn.linear_model import LogisticRegression
import numpy as np
from numba import jit
from sklearn.model_selection import StratifiedKFold
from math import log

def calc_log_ratio(predictions, weights, eta, delta):
    pos_weight_votes = predictions.dot(weights)
    neg_weight_votes = (1.0-predictions).dot(weights)
    empirical_log_ratio = (1 / float(eta)) * np.log((pos_weight_votes+1e-5)/(neg_weight_votes+1e-5))
    return empirical_log_ratio

class ensembled_linear_classifier:
    def __init__(self, eta=1.0, delta=0.1):#, tau=3):
        """
        Ensembles linear classifiers and weights like Freund and Shapire.
        """
        self.eta = eta
        self.delta = delta
        #self.tau = tau

    def train(self, x, y, sample_weight=None):
        if sample_weight is None:
            sample_weight = np.ones(len(y))
        self.ensemble = BaggingClassifier(
            LogisticRegression(C=1e1),
            n_estimators=10,
            warm_start=False,
            n_jobs=5)
        self.ensemble.fit(x, y, sample_weight)
        self.losses = 1 - np.array([dt.score(x, y) for dt in self.ensemble.estimators_])
        x_pred = self.ensemble.predict(x)
        pos_fraction = np.sum(x_pred == 1)/float(len(x_pred))
        neg_count = np.sum((x_pred == 0) * (y == 0))
        return pos_fraction, neg_count

    def evaluate(self, x, eta=None, delta=None, tau=None):
        if eta is None:
            eta = self.eta
        if delta is None:
            delta = self.delta
        # if tau is None:
        #     tau = self.tau

        weights = np.exp(-eta * self.losses)# / np.power(tree_losses, self.tau)
        predictions = np.array([est.predict(x) for est in self.ensemble.estimators_]).T
        eta = eta if eta != 0.0 else 1.0
        empirical_log_ratio = calc_log_ratio(predictions, weights, eta, delta)
        use_prediction = (np.abs(empirical_log_ratio) >= delta).astype(int)
        prediction = (use_prediction * (empirical_log_ratio > 0)).astype(np.float)
        prediction[use_prediction == 0] = np.nan
        return prediction

class cv_ensembled_linear_classifier:
    def __init__(self):
        self.hyperparam_grid = np.array([
            [eta, delta]
            for eta in np.linspace(0, 8, 40)
            for delta in np.geomspace(1e-4, 0.1 + 2.0 / (eta + 1.0), 20)
        ])

    def train(self, x, y, weight=1.0, n_cv=10, n_hyperparams=30, epsilon=0.01):
        possible_hyperparameter_settings = self.hyperparam_grid.shape[0]
        hyperparam_candidates_idx = np.random.choice(
            possible_hyperparameter_settings, n_hyperparams, replace=False)
        hyperparam_candidates = self.hyperparam_grid[hyperparam_candidates_idx]

        kfold = StratifiedKFold(n_splits=n_cv)
        classifier = ensembled_linear_classifier()

        # it's like golf, low score is better
        scores = {(eta, delta): [] for eta, delta in hyperparam_candidates}
        coverage = {(eta, delta): [] for eta, delta in hyperparam_candidates}
        for train, test in kfold.split(x, y):
            X_train = x[train]
            y_train = y[train]
            X_test = x[test]
            y_test = y[test]
            classifier.train(X_train, y_train)
            for eta, delta in hyperparam_candidates:
                y_eval = classifier.evaluate(X_test, eta=eta, delta=delta)
                selection = np.logical_not(np.isnan(y_eval))
                err = (y_test[selection] != y_eval[selection]).mean()
                coverage[(eta, delta)].append(selection.mean())
                if (selection.sum() > 0):
                    scores[(eta, delta)].append(err)
        evaled_err = np.array([np.array(scores[hyperparameters]).mean() for hyperparameters in scores.keys()])
        evaled_coverage = np.array([np.array(coverage[hyperparameters]).mean() for hyperparameters in scores.keys()])

        evaled_etas = np.array([hyperparameters[0] for hyperparameters in scores.keys()])
        evaled_deltas = np.array([hyperparameters[1] for hyperparameters in scores.keys()])

        lowest_err = np.nanmin(evaled_err)
        acceptable_hyperparams = evaled_err < lowest_err + epsilon
        useful_hyperparam = np.nanargmax(evaled_coverage[acceptable_hyperparams])

        self.delta = (evaled_deltas[acceptable_hyperparams])[useful_hyperparam]
        self.eta = (evaled_etas[acceptable_hyperparams])[useful_hyperparam]

        self.classifier = ensembled_linear_classifier(eta=self.eta, delta=self.delta)
        self.classifier.train(x, y)
        x_pred = self.classifier.evaluate(x)
        pos_fraction = np.sum(x_pred == 1)/float(len(x_pred))
        neg_count = np.sum((x_pred == 0) * (y == 0))
        return pos_fraction, neg_count

    def evaluate(self, x):
        return self.classifier.evaluate(x)
