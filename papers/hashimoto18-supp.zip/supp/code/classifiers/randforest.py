from sklearn.ensemble import RandomForestClassifier
import numpy as np


class randforest_classifier:
    def __init__(self):
        """
        Random forest classifier
        """
        pass

    def train(self, x, y, weight=None):
        if weight is None:
            weight = np.ones(len(y))
        self.rf = RandomForestClassifier()
        self.rf.fit(x, y, weight)
        x_pred = self.rf.predict(x)
        pos_fraction = np.sum(x_pred == 1)/float(len(x_pred))
        neg_count = np.sum((x_pred == 0) * (y == 0))
        return pos_fraction, neg_count

    def evaluate(self, x):
        return (np.array([dt.predict(x) for dt in self.rf.estimators_]) \
                .mean(axis=0) > 0.5).astype(np.int)
