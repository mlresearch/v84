import numpy as np
import matplotlib.pyplot as plt
from numba import jit

import scipy.linalg

@jit
def line_search(d_t, x, beta, y, lambda_, reg_mask, eps):
    g_t = -d_t
    alpha = 1e-8
    while d_t.dot(g_t) < 0:
        alpha = alpha * 2
        beta_t = beta + alpha * d_t
        mu_t = 1 / (1 + np.exp(-x.dot(beta_t)))
        g_t = x.T.dot(mu_t - y) + lambda_ * reg_mask * beta_t

    alpha_u = alpha
    alpha_l = alpha / 2
    while abs(d_t.dot(g_t)) > eps * np.linalg.norm(d_t):
        alpha = (alpha_u + alpha_l) / 2
        beta_t = beta + alpha * d_t
        mu_t = 1 / (1 + np.exp(-x.dot(beta_t)))
        g_t = x.T.dot(mu_t - y) + lambda_ * reg_mask * beta_t

        if d_t.dot(g_t) > 0:
            alpha_u = alpha
        else:
            alpha_l = alpha
    return alpha

class css_classifier:
    def __init__(self, lambda_):
        """
        Example classifier using CSS with a logistic sub-routine.
        :param C: regularization constant for trading off errors and margin.
                  C -> infty is hard margin (allow no errors and max margin).
        """
        self.lambda_ = lambda_

    def train(self, x, y, weight=1.0):
        self.train_x = x
        self.train_y = y
        self.n, self.d = x.shape
        self._fit_logistic(x, y)
        x_pred = self._predict(x)
        pos_fraction = np.sum(x_pred == 1)/float(len(x_pred))
        neg_count = np.sum((x_pred == 0) * (y == 0))
        return pos_fraction, neg_count

    def _fit_logistic(self, x, y):
        n, d = x.shape
        beta = (0, np.zeros(d))

        self.beta = self._newton_logistic_loss(x, y, beta, n, d, T=100, eps=1e-10)

    def _newton_logistic_loss(self, x, y, beta, n, d, T=20, eps=1e-10):
        x = np.hstack((x, np.ones(n)[:, np.newaxis]))

        beta = np.concatenate((beta[1], np.array([beta[0]])))

        reg_mat = np.eye(d+1)
        reg_mat[-1, -1] = 0

        reg_mask = np.ones(d+1)
        reg_mask[-1] = 0
        
        for t in range(T):
            beta_prev = beta

            mu_t = 1 / (1 + np.exp(-x.dot(beta)))
            g_t = x.T.dot(mu_t - y)
            g_t = g_t + self.lambda_ * reg_mask * beta
            H_t = (x.T * (mu_t * (1 - mu_t))).dot(x) + self.lambda_ * reg_mat
            d_t = -scipy.linalg.solve(H_t, g_t, sym_pos=True)

            alpha = line_search(d_t, x, beta, y, self.lambda_, reg_mask, eps)

            beta = beta + alpha * d_t

            if np.linalg.norm(beta_prev - beta) < eps:
                break

        return (beta[-1], beta[:-1])

    def _predict(self, x, beta=None):
        if beta is None:
            beta = self.beta

        return (x.dot(beta[1]) + beta[0] > 0).astype(int)

    def _eval_0_1_loss(self, x, y, beta=None):
        prediction = self._predict(x, beta)
        return np.mean(y != prediction)

    def _css_predict(self, x, eps=1e-5):
        eval_x = np.vstack((x, self.train_x))
        eval_y = np.concatenate((np.array([0]), self.train_y))
        beta_0 = self._newton_logistic_loss(eval_x, eval_y,
                                            self.beta, self.n + 1, self.d,
                                            T=100, eps=1e-10)
        err_0 = self._eval_0_1_loss(eval_x, eval_y, beta_0)
        eval_y = np.concatenate((np.array([1]), self.train_y))
        beta_1 = self._newton_logistic_loss(eval_x, eval_y,
                                            self.beta, self.n + 1, self.d,
                                            T=100, eps=1e-10)
        err_1 = self._eval_0_1_loss(eval_x, eval_y, beta_1)
        if abs(err_1 - err_0) < eps:
            return np.nan
        else:
            return 1 if err_1 < err_0 else 0

    def evaluate(self, x):
        return np.apply_along_axis(lambda row: self._css_predict(row), axis=1, arr=x)
