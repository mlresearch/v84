#!/bin/bash
curl -o BAR15A_PBM_full.tgz -X POST --data 'filename=BAR15A/BAR15A_PBM_full.tgz&Submit=Start' http://thebrain.bwh.harvard.edu/uniprobe/downbulk.php?file=BAR15A/BAR15A_PBM_full.tgz
mkdir -p PBM
tar -xzf BAR15A_PBM_full.tgz -C PBM/ --wildcards --no-anchored '*8mers.txt' --strip-components 4
rm BAR15A_PBM_full.tgz
