import io
import glob
import os.path
import numpy as np

import time
from itertools import product

from sklearn.datasets import fetch_mldata
from sklearn.linear_model import SGDClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.utils import check_random_state

from functools import partial
import multiprocessing

def fit_with_params(parameters, X_train, y_train, X_test, y_test):
    clf = SGDClassifier(loss='log',
                        penalty='elasticnet',
                        alpha=parameters[0],
                        l1_ratio=parameters[1],
                        max_iter=parameters[2],
                        learning_rate='invscaling',
                        eta0=parameters[3],
                        power_t=parameters[4],
                        tol=parameters[5])
    clf.fit(X_train, y_train)
    score = clf.score(X_test, y_test)
    return score

class mnist_logistic_hyperparameter_experiment:
    """
    Abstract class defining the contract for a discprete objective function
    """
    def __init__(self, seed=0):
        train_samples = 5000

        print "fetching mnist..."
        mnist = fetch_mldata('MNIST original')
        print "...done."
        X = mnist.data.astype('float64')
        y = mnist.target
        self.seed = seed
        self.random_state = check_random_state(seed)
        self.permutation = self.random_state.permutation(X.shape[0])
        X = X[self.permutation]
        y = y[self.permutation]
        X = X.reshape((X.shape[0], -1))

        self.X_train, self.X_test, self.y_train, self.y_test = \
            train_test_split(
                X, y, train_size=train_samples, test_size=10000)
        self.scaler = StandardScaler()
        self.X_train = self.scaler.fit_transform(self.X_train)
        self.X_test = self.scaler.transform(self.X_test)

        try:
            self.cpus = multiprocessing.cpu_count()
        except NotImplementedError:
            self.cpus = 2   # arbitrary default

        self.pool = multiprocessing.Pool(processes=self.cpus)

    def actions(self):
        return np.array(list(product(
            np.geomspace(1e-10, 1, 10),
            np.linspace(0, 1, 5),
            np.logspace(3, 30, 14, base=2),
            np.geomspace(1e-10, 1, 8),
            np.geomspace(0.25, 1, 3),
            np.geomspace(1e-5, 1e-1, 6))))

    def evaluate(self, parameters_list):
        """ given N x D array with points to evaluate
        return D values in an array.
        if any point is not in the action space, return NaN
        """
        return self.pool.map(partial(fit_with_params,
                                     X_train=self.X_train,
                                     y_train=self.y_train,
                                     X_test=self.X_test,
                                     y_test=self.y_test),
                             parameters_list)

    def feasible(self):
        """ given N x D array with points to evaluate,
        return D booleans indicating whether the points in the action space.
        """
        raise Exception('Not Implemented.')
