import numpy as np
from functions.eval_function import eval_function

class hartmann(eval_function):
    def __init__(self):
        """
        Defines the Hartmann 6-D function as defined in
        [this R code](https://www.sfu.ca/~ssurjano/hart6.html).
        """
        self.d = 6
        self.lower_limits = np.zeros(6)
        self.upper_limits = np.ones(6)

        self.alpha = np.array([1.0, 1.2, 3.0, 3.2])
        
        self.A = np.array([
            10, 3, 17, 3.5, 1.7, 8,
            0.05, 10, 17, 0.1, 8, 14,
            3, 3.5, 1.7, 10, 17, 8,
            17, 8, 0.05, 10, 0.1, 14
        ])
        self.A = np.reshape(self.A, (4, 6))

        self.P = 1e-4 * np.array([
            1312, 1696, 5569, 124, 8283, 5886,
            2329, 4135, 8307, 3736, 1004, 9991,
            2348, 1451, 3522, 2883, 3047, 6650,
            4047, 8828, 8732, 5743, 1091, 381
        ])
        self.P = np.reshape(self.P, (4, 6))

        self.min = [
            (0.20169, 0.150011, 0.476874, 0.275332, 0.311652, 0.6573)
        ]
        self.fmin = -3.32237
        self.name = 'Hartmann 6'

    def _f(self, x):
        xxmat = np.tile(x,(4,1))
        inner = (self.A * np.square(xxmat-self.P)).sum(axis=1)
	
        outer = (self.alpha * np.exp(-inner)).sum()
	
        fval = -outer
        return(fval)
