import numpy as np

class eval_function:
    def __init__(self):
        self.d = 2
        self.lower_limits = np.array([0, 1])
        self.upper_limits = np.array([0, 1])

    def bounds(self):
        return [self.lower_limits, self.upper_limits]

    def feasible(self, x):
        feasible_list = []
        for xi in x:
            feasible_list.append(
                np.all((xi > self.lower_limits)*(xi < self.upper_limits))
            )
        return feasible_list

    def evaluate(self, x):
        evaluated_values = []
        for xi in x:
            assert self.feasible(xi)
            evaluated_values.append(self._f(xi))
        return evaluated_values

    def _f(x):
        pass
