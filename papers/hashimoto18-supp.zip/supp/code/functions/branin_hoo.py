import numpy as np
from functions.eval_function import eval_function

class branin_hoo(eval_function):
    def __init__(self):
        """
        Defines the Branin-Hoo function as implemented in
        [GPyOpt](https://github.com/SheffieldML/GPyOpt/blob/master/GPyOpt/objective_examples/experiments2d.py)
        This is a 2-D function.
        """
        self.d = 2
        self.lower_limits = np.array([-5, 1])
        self.upper_limits = np.array([10, 15])

        self.a = 1
        self.b = 5.1/(4*np.pi**2)
        self.c = 5/np.pi
        self.r = 6
        self.s = 10 
        self.t = 1/(8*np.pi)

        self.min = [(-np.pi,12.275),(np.pi,2.275),(9.42478,2.475)]
        self.fmin = 0.397887
        self.name = 'Branin'

    def _f(self, x):
        x1 = x[0]
        x2 = x[1]
        fval = self.a * (x2 - self.b*x1**2 + self.c*x1 - self.r)**2 + \
            self.s*(1-self.t)*np.cos(x1) + self.s 
        return fval
