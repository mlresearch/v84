import numpy as np
from functions.eval_function import eval_function

class shekel(eval_function):
    def __init__(self, m=10):
        """
        Defines the Shekel function with m modes as defined in
        [this R code](https://www.sfu.ca/~ssurjano/Code/shekelr.html)
        This is a 4-D function.
        """
        self.d = 4
        self.lower_limits = np.zeros(4)
        self.upper_limits = 10 * np.ones(4)

        self.m = m
        self.b = 0.1 * np.array([1, 2, 2, 4, 4, 6, 3, 7, 5, 5])
        self.C = np.array([4.0, 1.0, 8.0, 6.0, 3.0, 2.0, 5.0, 8.0, 6.0, 7.0,
                           4.0, 1.0, 8.0, 6.0, 7.0, 9.0, 3.0, 1.0, 2.0, 3.6,
                           4.0, 1.0, 8.0, 6.0, 3.0, 2.0, 5.0, 8.0, 6.0, 7.0,
                           4.0, 1.0, 8.0, 6.0, 7.0, 9.0, 3.0, 1.0, 2.0, 3.6])
        self.C = np.reshape(self.C, (4, 10))

        self.min = [(4, 4, 4, 4)]
        self.fmin = -10.5363
        self.name = 'Shekel'

    def _f(self, x):
        xxmat = np.tile(x,(self.m,1))
        inner = np.square(xxmat-self.C.T).sum(axis=1)
	
        outer = (1 / (inner+self.b)).sum()
	
        fval = -outer
        return(fval)
