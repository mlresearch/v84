import numpy as np
from functions.eval_function import eval_function

class cosine_mixture(eval_function):
    def __init__(self):
        """
        Defines the cosine mixture function as defined in
        [GPyOpt](https://github.com/SheffieldML/GPyOpt/blob/master/GPyOpt/objective_examples/experiments2d.py)
        This is a 2-D function.
        """
        self.d = 2
        self.lower_limits = np.zeros(2)
        self.upper_limits = np.ones(2)

        self.min = [(0.31426205,  0.30249864)]
        self.fmin = -1.59622468
        self.name = 'Cosines'

    def _f(self, x):
        u = 1.6*x[0]-0.5
        v = 1.6*x[1]-0.5
        fval = -(1 - (
            u ** 2 + v ** 2 - 0.3 * np.cos(3 * np.pi * u) - \
            0.3 * np.cos(3 * np.pi * v)))
        return fval
