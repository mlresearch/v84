import io
import glob
import os.path
import numpy as np


def get_pbm_files():
    my_path = os.path.abspath(os.path.dirname(__file__))
    path = os.path.join(my_path, "../dataset/PBM/*")
    return glob.glob(path)


def parse_pbm_file(path):
    seq_list = []
    fl_list = []
    with io.open(path, 'r') as fopen:
        lnum = 0
        for line in fopen:
            if lnum > 0:
                stripped = line.strip().split('\t')
                seq_list.append(stripped[0])
                fl_list.append(float(stripped[3]))
                seq_list.append(stripped[1])
                fl_list.append(float(stripped[3]))
            lnum += 1
    return seq_list, fl_list


char_list = np.array(['A', 'T', 'C', 'G'])


def action_to_seq(vec, seqdict):
    if len(vec) != 4*8:
        return float('nan')
    else:
        nzvec = np.nonzero(vec)[0]
        if len(nzvec) != 8:
            return float('nan')
        elif np.any(np.floor_divide(nzvec, 4) != np.arange(8)):
            return float('nan')
        return seqdict[''.join(char_list[np.mod(nzvec, 4)])]


def seq_to_action(seqlist):
    ret_list = []
    for seq in seqlist:
        cbase = np.arange(0, 32, step=4)
        for i in range(4):
            cidx = np.array(list(seq)) == char_list[i]
            cbase += cidx*i
        nret = np.zeros(32)
        nret[cbase] = 1
        ret_list.append(nret)
    return np.array(ret_list)


class pbm_experiment:
    """
    Abstract class defining the contract for a discprete objective function
    """
    def __init__(self, seed=0):
        self.pbm_files = np.sort(np.array(get_pbm_files()))
        np.random.seed(0)
        perm = np.random.permutation(len(self.pbm_files))
        self.pbm_selected = self.pbm_files[perm[seed]]
        self.seq_list, self.fl_list = parse_pbm_file(self.pbm_selected)
        self.seq_dict = dict(zip(np.array(self.seq_list),
                                 -1*np.array(self.fl_list)))
        self.pbm_name = self.pbm_selected.split('/')[-1].split('.')[0]

    def actions(self):
        return seq_to_action(self.seq_list)

    def evaluate(self, actions):
        """ given N x D array with points to evaluate
        return D values in an array.
        if any point is not in the action space, return NaN
        """
        return [action_to_seq(action, self.seq_dict) for action in actions]

    def feasible(self):
        """ given N x D array with points to evaluate,
        return D booleans indicating whether the points in the action space.
        """
        raise Exception('Not Implemented.')

        
