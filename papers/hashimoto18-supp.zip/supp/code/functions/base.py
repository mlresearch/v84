import functions.branin_hoo
import functions.cosines
import functions.hartmann
import functions.optfun
import functions.shekel


class abstract_discr_opt:
    """
    Abstract class defining the contract for a discrete objective function
    """
    def __init__(self, seed=0):
        """ init sets up the objective.
        for random objectives, it can take a seed
        """
        pass

    def actions(self):
        """ return a list N x D of all possible actions """
        pass

    def evaluate(self):
        """ given N x D array with points to evaluate
        return D values in an array.
        if any point is not in the action space, return NaN
        """

    def feasible(self):
        """ given N x D array with points to evaluate,
        return D booleans indicating whether the points in the action space.
        """


class abstract_cont_opt:
    """
    Abstract class defining the contract for a continuous objective function
    """
    def __init__(self, seed=0):
        """ init sets up the objective.
        for random objectives, it can take a seed
        """
        pass

    def bounds(self):
        """ return a list, [lower_bounds, upper_bounds] """
        pass

    def evaluate(self):
        """ given N x D array with points to evaluate
        return D values in an array.
        if any point is out of bounds, return NaN.
        """

    def feasible(self):
        """ given N x D array with points to evaluate,
        return D booleans indicating in/out of bounds
        """


# dict containing all functions
all_cont_functions = {
    'branin_hoo': functions.branin_hoo.branin_hoo,
    'cosine_mixture': functions.cosines.cosine_mixture,
    'hartmann': functions.hartmann.hartmann,
    'shekel': functions.shekel.shekel
}

linear_cont_functions = {
    'linear_objective': functions.optfun.linear_objective,
    'rand_linquad_obj': functions.optfun.rand_linquad_obj
}
