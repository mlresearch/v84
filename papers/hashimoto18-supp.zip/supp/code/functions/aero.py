import os
import math
import numpy
from scipy import integrate
import numpy as np
from math import *


class airfoil_discrete:
    def __init__(self, seed=0):
        self.alpha = 5.0
        self.u_inf = 1.0
        self.N = 20
        self.dim = 100
        self.ndim = self.dim*2-1
        self.nx = NACA4('0001', self.dim)[:, 0]
        self.nlist = [NACA4(format(i+1, '04'), self.dim)[:, 1]
                      for i in range(9998)]

    def actions(self):
        """ return a list of actions """
        return np.array(self.nlist)

    def evaluate(self, x):
        """ given N x D array with points to evaluate
        return D values in an array.
        if any point is out of bounds, return NaN.
        """
        lift_list = []
        for xi in x:
            try:
                af = Airfoil(self.nx, xi, 40)
                af.set_freestream(self.u_inf, self.alpha)
                af.simulate_airflow()
                lift = -1*af.cl / (np.max(xi)-np.min(xi)+0.01)
            except:
                lift = 0
            if np.isnan(lift):
                lift = 0
            lift_list.append(lift)
        return np.array(lift_list)
    
    def feasible(self, x):
        """ given N x D array with points to evaluate,
        return D booleans indicating in/out of bounds
        """
        raise Exception('Not implemented')


def airfoil_map(dat_in):
    """
    coordinates are encoded as packed
    [top_dx1,dx2 ... dxn, top_dy1, dy2 ... dyn, bottom_dx1 ...]
    length must be a multiple of 8
    constraint - dx must be > 0
    constraint - dy must be > 0.
    """
    assert len(dat_in) % 8 == 0
    dat_halves = np.split(dat_in, 2)
    top_x, top_y = airfoil_half(dat_halves[0])
    bottom_x, bottom_y = airfoil_half(dat_halves[1])
    zero = np.array([0])
    return np.concatenate([top_x[::-1], zero, bottom_x[:-1]]),\
        np.concatenate([top_y[::-1], zero, -bottom_y[:-1]])


def airfoil_half(dat_in):
    """
    for 1 .. n/2 dys are added, for n/2+1 -> n they are subtracted.
    normalize x to sum-to-one.
    normalize y to sum-to-zero (after flipping n/2+1 ..)
    """
    dat_split = np.split(dat_in, 2)
    x_seq = np.cumsum(dat_split[0]) / np.sum(dat_split[0])
    assert len(dat_split[1]) % 2 == 0
    y_split = np.split(dat_split[1], 2)
    y_rise = np.cumsum(y_split[0])
    y_fall = (np.sum(y_split[0]) - np.cumsum(y_split[1])
              * np.sum(y_split[0]) / np.sum(y_split[1]))
    y_seq = np.concatenate([y_rise, y_fall])
    return x_seq, y_seq


class Airfoil:
    """ Encapsulates airfoil related data and calculations """
    def __init__(self, x, y, N=40):
        self.xs = x
        self.ys = y
        self.N = N
        self.panels = define_panels(x, y, N)
        self.freestream = Freestream()

    def set_freestream(self, u_inf, alpha):
        """ sets the angle of attack (alpha) and fluid velocity (u_inf) """
        self.alpha = alpha
        self.u_inf = u_inf
        self.freestream = Freestream(u_inf, alpha)

    def simulate_airflow(self):
        A_source = source_contribution_normal(self.panels)
        B_vortex = vortex_contribution_normal(self.panels)
        A = build_singularity_matrix(A_source, B_vortex)
        b = build_freestream_rhs(self.panels, self.freestream)
        # solve for singularity strengths
        strengths = numpy.linalg.solve(A, b)
        # store source strength on each panel
        for i, panel in enumerate(self.panels):
            panel.sigma = strengths[i]
        # store circulation density
        gamma = strengths[-1]
        # tangential velocity at each panel center.
        compute_tangential_velocity(self.panels, self.freestream,
                                    gamma, A_source, B_vortex)
        # computes the surface pressure coefficients
        get_pressure_coefficient(self.panels, self.freestream)
        # calculate the accuracy
        self.accuracy = sum([panel.sigma*panel.length
                             for panel in self.panels])
        # calculate lift coefficient
        c = abs(max(panel.xa for panel in self.panels)
                - min(panel.xa for panel in self.panels))
        self.cl = (gamma*sum(panel.length for panel in self.panels)
                   / (0.5*self.freestream.u_inf*c))

    def plot_all(self):
        pyplot.figure(figsize=(10, 7))
        pyplot.subplot2grid((3, 2), (0, 0))
        self.plot_panels()
        pyplot.subplot2grid((3, 2), (1, 0))
        self.plot_vfield()
        pyplot.subplot2grid((3, 2), (2, 0))
        self.plot_pressure_contour()
        pyplot.subplot2grid((3, 2), (0, 1), colspan=1, rowspan=3)
        self.plot_cp()
        pyplot.tight_layout()

    def plot_airfoil(self):
        pyplot.grid()
        pyplot.xlabel('x', fontsize=16)
        pyplot.ylabel('y', fontsize=16)
        pyplot.plot(self.xs, self.ys, color='k', linestyle='-', linewidth=2)
        pyplot.axis('scaled', adjustable='box')
        pyplot.tight_layout()

    def plot_panels(self):
        pyplot.grid()
        pyplot.xlabel('x', fontsize=16)
        pyplot.ylabel('y', fontsize=16)
        pyplot.plot(self.xs, self.ys, color='k', linestyle='-', linewidth=2)
        pyplot.plot(numpy.append([panel.xa for panel in self.panels],
                                 self.panels[0].xa),
                    numpy.append([panel.ya for panel in self.panels],
                                 self.panels[0].ya),
                    linestyle='-', linewidth=1, marker='o',
                    markersize=6, color='#CD2305')
        pyplot.axis('scaled', adjustable='box')
        pyplot.xlim(-0.1, 1.1)
        pyplot.ylim(-0.1, 0.1)
        pyplot.tight_layout()

    def plot_cp(self):
        # plot the surface pressure coefficient
        pyplot.grid()
        pyplot.xlabel('x', fontsize=16)
        pyplot.ylabel('$C_p$', fontsize=16)
        pyplot.plot([panel.xc for panel in self.panels
                     if panel.loc == 'upper'],
                    [panel.cp for panel in self.panels
                     if panel.loc == 'upper'],
                    label='upper',
                    color='r', linewidth=1, marker='x', markersize=8)
        pyplot.plot([panel.xc for panel in self.panels
                     if panel.loc == 'lower'],
                    [panel.cp for panel in self.panels
                     if panel.loc == 'lower'],
                    label='lower',
                    color='b', linewidth=0, marker='d', markersize=6)
        pyplot.legend(loc='best', prop={'size': 14})
        pyplot.xlim(-0.1, 1.1)
        #pyplot.ylim(1.0, -0.6)
        pyplot.title('Number of panels : %d, Acc: %f, Cl: %f' %
                     (self.N, self.accuracy, self.cl))
        pyplot.tight_layout()

    def plot_vfield(self):
        # define a mesh grid
        nx, ny = 20, 20  # number of points in the x and y directions
        x_start, x_end = -1.0, 2.0
        y_start, y_end = -0.3, 0.3
        X, Y = numpy.meshgrid(numpy.linspace(x_start, x_end, nx),
                              numpy.linspace(y_start, y_end, ny))
        # compute the velocity field on the mesh grid
        u, v = get_velocity_field(self.panels, self.freestream, X, Y)
        # plot the velocity field
        pyplot.xlabel('x', fontsize=16)
        pyplot.ylabel('y', fontsize=16)
        pyplot.streamplot(X, Y, u, v,
                          density=1, linewidth=1, arrowsize=1, arrowstyle='->')
        pyplot.fill([panel.xc for panel in self.panels],
                    [panel.yc for panel in self.panels],
                    color='k', linestyle='solid', linewidth=2, zorder=2)
        pyplot.axis('scaled', adjustable='box')
        pyplot.xlim(x_start, x_end)
        pyplot.ylim(y_start, y_end)
        pyplot.title('Streamlines (AoA = ${}^o$)'.format(self.alpha),
                     fontsize=16)
        pyplot.tight_layout()

    def plot_pressure_contour(self):
        nx, ny = 20, 20  # number of points in the x and y directions
        x_start, x_end = -1.0, 2.0
        y_start, y_end = -0.3, 0.3
        X, Y = numpy.meshgrid(numpy.linspace(x_start, x_end, nx),
                              numpy.linspace(y_start, y_end, ny))
        # compute the pressure field
        u, v = get_velocity_field(self.panels, self.freestream, X, Y)
        cp = 1.0 - (u**2+v**2)/self.freestream.u_inf**2
        # plot the pressure field
        pyplot.xlabel('x', fontsize=16)
        pyplot.ylabel('y', fontsize=16)
        contf = pyplot.contourf(X, Y, cp,
                                levels=numpy.linspace(-2.0, 1.0, 100),
                                extend='both')
        cbar = pyplot.colorbar(contf,
                               orientation='horizontal',
                               shrink=0.5, pad=0.1,
                               ticks=[-2.0, -1.0, 0.0, 1.0])
        cbar.set_label('$C_p$', fontsize=16)
        pyplot.fill([panel.xc for panel in self.panels],
                    [panel.yc for panel in self.panels],
                    color='k', linestyle='solid', linewidth=2, zorder=2)
        pyplot.axis('scaled', adjustable='box')
        pyplot.xlim(x_start, x_end)
        pyplot.ylim(y_start, y_end)
        pyplot.title('Contour of pressure field', fontsize=16)
        pyplot.tight_layout()


"""
Code below adapted from the vortex source panel calculations in
https://github.com/barbagroup/AeroPython/blob/master/lessons/11_Lesson11_vortexSourcePanelMethod.ipynb
"""


class Panel:
    """
    Contains information related to a panel.
    """
    def __init__(self, xa, ya, xb, yb):
        """
        Initializes the panel.
        Sets the end-points and calculates the center, length,
        and angle (with the x-axis) of the panel.
        Defines if the panel is on the lower or upper surface of the geometry.
        Initializes the source-sheet strength, tangential velocity,
        and pressure coefficient to zero.
        Parameters
        ----------
        xa: float
            x-coordinate of the first end-point.
        ya: float
            y-coordinate of the first end-point.
        xb: float
            x-coordinate of the second end-point.
        yb: float
            y-coordinate of the second end-point.
        """
        self.xa, self.ya = xa, ya
        # control-point (center-point)
        self.xc, self.yc = (xa+xb)/2, (ya+yb)/2
        # length of the panel
        self.length = math.sqrt((xb-xa)**2+(yb-ya)**2)
        # orientation of the panel (angle between x-axis and panel's normal)
        if xb-xa <= 0.:
            self.beta = math.acos((yb-ya)/self.length)
        elif xb-xa > 0.:
            self.beta = math.pi + math.acos(-(yb-ya)/self.length)
        # location of the panel
        if self.beta <= math.pi:
            self.loc = 'upper'
        else:
            self.loc = 'lower'
        self.sigma = 0.                             # source strength
        self.vt = 0.                                # tangential velocity
        self.cp = 0.                                # pressure coefficient


def define_panels(x, y, N=40):
    """
    Discretizes the geometry into panels using the 'cosine' method.
    Parameters
    ----------
    x: 1D array of floats
        x-coordinate of the points defining the geometry.
    y: 1D array of floats
        y-coordinate of the points defining the geometry.
    N: integer, optional
        Number of panels;
        default: 40.
    Returns
    -------
    panels: 1D Numpy array of Panel objects
        The discretization of the geometry into panels.
    """
    # radius of the circle
    R = (x.max()-x.min())/2
    # x-coord of the center
    x_center = (x.max()+x.min())/2
    # x-coord of the circle points
    x_circle = x_center + R*numpy.cos(numpy.linspace(0, 2*math.pi, N+1))
    # projection of the x-coord on the surface
    x_ends = numpy.copy(x_circle)
    # initialization of the y-coord Numpy array
    y_ends = numpy.empty_like(x_ends)
    # extend arrays using numpy.append
    x, y = numpy.append(x, x[0]), numpy.append(y, y[0])
    # computes the y-coordinate of end-points
    I = 0
    for i in range(N):
        while I < len(x)-1:
            if (x[I] <= x_ends[i] <= x[I+1]) or (x[I+1] <= x_ends[i] <= x[I]):
                break
            else:
                I += 1
        a = (y[I+1]-y[I])/(x[I+1]-x[I])
        b = y[I+1] - a*x[I+1]
        y_ends[i] = a*x_ends[i] + b
    y_ends[N] = y_ends[0]
    panels = numpy.empty(N, dtype=object)
    for i in range(N):
        panels[i] = Panel(x_ends[i], y_ends[i], x_ends[i+1], y_ends[i+1])
    return panels


class Freestream:
    """
    Freestream conditions.
    """
    def __init__(self, u_inf=1.0, alpha=0.0):
        """
        Sets the freestream speed and angle (with the x-axis).
        Parameters
        ----------
        u_inf: float, optional
            Freestream speed;
            default: 1.0.
        alpha: float, optional
            Angle of attack in degrees;
            default: 0.0.
        """
        self.u_inf = u_inf
        self.alpha = alpha*math.pi/180          # degrees --> radians


def integral(x, y, panel, dxdz, dydz):
    """
    Evaluates the contribution of a panel at one point.
    Parameters
    ----------
    x: float
        x-coordinate of the target point.
    y: float
        y-coordinate of the target point.
    panel: Panel object
        Source panel which contribution is evaluated.
    dxdz: float
        Derivative of x in the z-direction.
    dydz: float
        Derivative of y in the z-direction.
    Returns
    -------
    Integral over the panel of the influence at the given target point.
    """
    def integrand(s):
        return (((x - (panel.xa - math.sin(panel.beta)*s))*dxdz
                 + (y - (panel.ya + math.cos(panel.beta)*s))*dydz)
                / ((x - (panel.xa - math.sin(panel.beta)*s))**2
                   + (y - (panel.ya + math.cos(panel.beta)*s))**2))
    return integrate.quad(integrand, 0.0, panel.length, limit=100)[0]


def source_contribution_normal(panels):
    """
    Builds the source contribution matrix for the normal velocity.
    Parameters
    ----------
    panels: 1D array of Panel objects
        List of panels.
    Returns
    -------
    A: 2D Numpy array of floats
        Source contribution matrix.
    """
    A = numpy.empty((panels.size, panels.size), dtype=float)
    # source contribution on a panel from itself
    numpy.fill_diagonal(A, 0.5)
    # source contribution on a panel from others
    for i, panel_i in enumerate(panels):
        for j, panel_j in enumerate(panels):
            if i != j:
                A[i, j] = 0.5/numpy.pi*integral(panel_i.xc, panel_i.yc,
                                                panel_j,
                                                numpy.cos(panel_i.beta),
                                                numpy.sin(panel_i.beta))
    return A


def vortex_contribution_normal(panels):
    """
    Builds the vortex contribution matrix for the normal velocity.
    Parameters
    ----------
    panels: 1D array of Panel objects
        List of panels.
    Returns
    -------
    A: 2D Numpy array of floats
        Vortex contribution matrix.
    """
    A = numpy.empty((panels.size, panels.size), dtype=float)
    # vortex contribution on a panel from itself
    numpy.fill_diagonal(A, 0.0)
    # vortex contribution on a panel from others
    for i, panel_i in enumerate(panels):
        for j, panel_j in enumerate(panels):
            if i != j:
                A[i, j] = -0.5/numpy.pi*integral(panel_i.xc, panel_i.yc,
                                                 panel_j,
                                                 numpy.sin(panel_i.beta),
                                                 -numpy.cos(panel_i.beta))
    return A


def kutta_condition(A_source, B_vortex):
    """
    Builds the Kutta condition array.
    Parameters
    ----------
    A_source: 2D Numpy array of floats
        Source contribution matrix for the normal velocity.
    B_vortex: 2D Numpy array of floats
        Vortex contribution matrix for the normal velocity.
    Returns
    -------
    b: 1D Numpy array of floats
        The left-hand side of the Kutta-condition equation.
    """
    b = numpy.empty(A_source.shape[0]+1, dtype=float)
    # matrix of source contribution on tangential velocity
    # is the same than
    # matrix of vortex contribution on normal velocity
    b[:-1] = B_vortex[0, :] + B_vortex[-1, :]
    # matrix of vortex contribution on tangential velocity
    # is the opposite of
    # matrix of source contribution on normal velocity
    b[-1] = - numpy.sum(A_source[0, :] + A_source[-1, :])
    return b


def build_singularity_matrix(A_source, B_vortex):
    """
    Builds the left-hand side matrix of the system
    arising from source and vortex contributions.
    Parameters
    ----------
    A_source: 2D Numpy array of floats
        Source contribution matrix for the normal velocity.
    B_vortex: 2D Numpy array of floats
        Vortex contribution matrix for the normal velocity.
    Returns
    -------
    A:  2D Numpy array of floats
        Matrix of the linear system.
    """
    A = numpy.empty((A_source.shape[0]+1, A_source.shape[1]+1), dtype=float)
    # source contribution matrix
    A[:-1, :-1] = A_source
    # vortex contribution array
    A[:-1, -1] = numpy.sum(B_vortex, axis=1)
    # Kutta condition array
    A[-1, :] = kutta_condition(A_source, B_vortex)
    return A


def build_freestream_rhs(panels, freestream):
    """
    Builds the right-hand side of the system
    arising from the freestream contribution.
    Parameters
    ----------
    panels: 1D array of Panel objects
        List of panels.
    freestream: Freestream object
        Freestream conditions.
    Returns
    -------
    b: 1D Numpy array of floats
        Freestream contribution on each panel and on the Kutta condition.
    """
    b = numpy.empty(panels.size+1, dtype=float)
    # freestream contribution on each panel
    for i, panel in enumerate(panels):
        b[i] = -freestream.u_inf * numpy.cos(freestream.alpha - panel.beta)
    # freestream contribution on the Kutta condition
    b[-1] = -freestream.u_inf*(numpy.sin(freestream.alpha-panels[0].beta)
                               + numpy.sin(freestream.alpha-panels[-1].beta))
    return b


def compute_tangential_velocity(panels, freestream, gamma, A_source, B_vortex):
    """
    Computes the tangential surface velocity.
    Parameters
    ----------
    panels: 1D array of Panel objects
        List of panels.
    freestream: Freestream object
        Freestream conditions.
    gamma: float
        Circulation density.
    A_source: 2D Numpy array of floats
        Source contribution matrix for the normal velocity.
    B_vortex: 2D Numpy array of floats
        Vortex contribution matrix for the normal velocity.
    """
    A = numpy.empty((panels.size, panels.size+1), dtype=float)
    # matrix of source contribution on tangential velocity
    # is the same than
    # matrix of vortex contribution on normal velocity
    A[:, :-1] = B_vortex
    # matrix of vortex contribution on tangential velocity
    # is the opposite of
    # matrix of source contribution on normal velocity
    A[:, -1] = -numpy.sum(A_source, axis=1)
    # freestream contribution
    b = freestream.u_inf*numpy.sin([freestream.alpha-panel.beta
                                    for panel in panels])
    strengths = numpy.append([panel.sigma for panel in panels], gamma)
    tangential_velocities = numpy.dot(A, strengths) + b
    for i, panel in enumerate(panels):
        panel.vt = tangential_velocities[i]


def get_pressure_coefficient(panels, freestream):
    """
    Computes the surface pressure coefficients on the panels.
    Parameters
    ---------
    panels: 1D array of Panel objects
        The source panels.
    freestream: Freestream object
        The freestream conditions.
    """
    for panel in panels:
        panel.cp = 1.0 - (panel.vt/freestream.u_inf)**2


def get_velocity_field(panels, freestream, X, Y):
    """
    Computes the velocity field on a given 2D mesh.
    Parameters
    ---------
    panels: 1D array of Panel objects
        The source panels.
    freestream: Freestream object
        The freestream conditions.
    X: 2D Numpy array of floats
        x-coordinates of the mesh points.
    Y: 2D Numpy array of floats
        y-coordinate of the mesh points.
    Returns
    -------
    u: 2D Numpy array of floats
        x-component of the velocity vector field.
    v: 2D Numpy array of floats
        y-component of the velocity vector field.
    """
    # freestream contribution
    u = freestream.u_inf * math.cos(freestream.alpha) \
        * numpy.ones_like(X, dtype=float)
    v = freestream.u_inf * math.sin(freestream.alpha) \
        * numpy.ones_like(X, dtype=float)
    # add the contribution from each source (superposition powers!!!)
    vec_intregral = numpy.vectorize(integral)
    for panel in panels:
        u += panel.sigma / (2.0 * math.pi) * vec_intregral(X, Y, panel, 1, 0)
        v += panel.sigma / (2.0 * math.pi) * vec_intregral(X, Y, panel, 0, 1)
    return u, v


""" from naca.py

Created: 1/1/2015
Author: Michel Robijns

This file is part of naca which is released under the MIT license.
See the file LICENSE or go to http://opensource.org/licenses/MIT for full
license details.

Description:
    A set of functions to compute the coordinates of NACA airfoils. In this
    version, only the NACA 4-digit airfoil series has been implemented.
"""


def NACA4(number, N, half_cosine_spacing=True,
          closed_trailing_edge=True, save_to_file=False):
    """Computes coordinates of a NACA 4-digit airfoil [1].
    Arguments:
        number: Name of the requested 4-digt NACA airfoil entered as a string,
                i.e. '2412'
        N: Number of desired airfoil coordinates
    Optional arguments:
        half_cosine_spacing: Half cosine spacing ensures that the datapoints
                             are more widely spaced around the leading edge
                             where the curvature is greatest.
        closed_trailing_edge: The trailing edge has a small but finite
                              thickness when using equations in [1] unaltered.
        save_to_file: Saves the coordinates in a data file.
    Returns:
        A matrix with two columns pertaining to the x and y-coordinates,
        respectively. The sequence of coordinates is clockwise, starting at the
        trailing edge.
    Raises:
        ValueError: Airfoil number does not have four digits or N is negative
    References:
    .. [1] Abbott, I.H. and von Doenhoff, A.E., "Theory of Wing Sections,
       Including a summary of airfoil data", Dover Publications, pp. 111-123,
       1959.
    """
    # Check whether input parameters are valid or not
    if not (0 < int(number) < 10000 and N > 0):
        raise ValueError("Invalid input.")
    # Scale the input parameters. We want, for example, a thickess of 0.12
    # and not 12 and the maximum camber at 0.4 * c and not 4 * c.
    m = float(number[0])
    p = float(number[1])
    t = float(number[2:])
    if m != 0:
        m = m / 100
    if p != 0:
        p = p / 10
    if t != 0:
        t = t / 100
    # Half cosine spacing ensures that the datapoints are more widely spaced
    # around the leading edge where the curvature is greatest.
    if half_cosine_spacing:
        x = (1 - np.cos(np.linspace(0, pi, N, dtype=float))) / 2
    else:
        x = np.linspace(0, 1, N)
    # The trailing edge has a small but finite thickness by default. The gap
    # can be closed by utilizing a slightly different equation. See equation
    # 6.4 of Abbot and von Doenhoff
    if closed_trailing_edge:
        thickness = t / 0.20 * (0.29690 * np.sqrt(x) - 0.12600 * x - 0.35160 *
                                np.power(x, 2) + 0.28430 *
                                np.power(x, 3) - 0.10360 *
                                np.power(x, 4))
    else:
        thickness = t / 0.20 * (0.29690 * np.sqrt(x) - 0.12600 * x - 0.35160 *
                                np.power(x, 2) + 0.28430 *
                                np.power(x, 3) - 0.10150 *
                                np.power(x, 4))
    # Compute the y-coordinates of the camber line. See equation 6.4 of Abbot
    # and von Doenhoff
    fwd_x = x[x < p]
    aft_x = x[x >= p]
    if 0 < p < 1 and 0 < m < 1:
        fwd_camber = m / p**2 * (2 * p * fwd_x - np.power(fwd_x, 2))
        aft_camber = m / (1 - p)**2 * ((1 - 2 * p) + 2 * p * aft_x -
                                       np.power(aft_x, 2))
        camber = np.append(fwd_camber, aft_camber)
    else:
        camber = np.zeros(np.size(x))
    y_upper = np.add(camber, thickness)
    y_lower = np.subtract(camber, thickness)
    # Append the arrays that contain the x and y-coordinates
    x_upper = np.flipud(x)
    x_lower = x[1:]
    x = np.append(x_upper, x_lower)
    y_upper = np.flipud(y_upper)
    y_lower = y_lower[1:]
    y = np.append(y_upper, y_lower)
    # NumPy creates a tiny numerical error when adding and subtracting the two
    # arrays. A number of order 10^-17 is shown instead of 0. Likely due to the
    # computer's internal representation of numbers.
    if closed_trailing_edge:
        y[0] = 0
        y[-1] = 0
    coordinates = np.column_stack((x, y))
    if save_to_file:
        np.savetxt("NACA " + number + ".dat", coordinates,
                   delimiter='\t', fmt='%f', header="NACA " + number)
    return coordinates



def main():
    from matplotlib import pyplot
    naca_filepath = 'n0012.dat'
    with open(naca_filepath, 'r') as file_name:
        x, y = numpy.loadtxt(file_name, dtype=float,
                             delimiter='\t', unpack=True)
    mat = NACA4('3212', 100)
    print(mat.shape)
    x=mat[:, 0]
    y=mat[:, 1]
    test_foil = Airfoil(x, y, 30)
    test_foil.set_freestream(1, 4.0)
    test_foil.simulate_airflow()
    test_foil.plot_all()
    pyplot.show()


# read of the geometry from a data file
if __name__ == "__main__":
    main()
