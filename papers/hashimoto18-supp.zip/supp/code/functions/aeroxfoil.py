import os
import subprocess
import io
from functions.aero import NACA4
import numpy as np
import uuid

class xfoil:
    def __init__(self, seed=0):
        self.seed=seed
        self.check_xfoil()
        self.alpha = 4
        self.visc = 3*(10**6)
        self.N = 20
        self.dim = 100
        self.ndim = self.dim*2-1
        self.nx = NACA4('0001', self.dim)[:, 0]
        self.nlist = [NACA4(format(i+1, '04'), self.dim)[:, 1]
                      for i in range(9998)]
        self.nhash = [(str(self.nlist[i]),i) for i in range(len(self.nlist))]
        self.ndict = dict(self.nhash)

    def actions(self):
        """ return a list of actions """
        return np.array(self.nlist)

    def evaluate(self, x):
        lift_to_drag_list = []
        for xi in x:
            #try:
            #    
            #except:
            try: 
                iind = np.argmin(np.array([np.sum((xi - self.nlist[j])**2.0) for j in range(len(self.nlist))]))
                #iind = self.ndict[str(xi)]
                xfdict = self.run_xfoil_naca(iind, self.alpha, self.visc)
                lift_to_drag_list.append(float(xfdict['CL'])/float(xfdict['CD']))
            except:
                lift_to_drag_list.append(0)
            
                
        return -1*np.array(lift_to_drag_list)
    
    def check_xfoil(self):
        if subprocess.call("which xfoil > /dev/null", shell=True) > 0:
            raise Exception('could not launch xfoil command - does typing xfoil in console work?')

    def run_xfoil_naca(self, nacanum, alfa=4, visc=3e6, tmpdir='/tmp'):
        outfile = os.path.join(tmpdir,str(uuid.uuid4().hex)+'.txt')
        xfoil_runstr="cd "+tmpdir+" && rm -f "+outfile+" && printf \"NACA {nnum}\nPANE\nOPER\nvisc\n{rnum:.1e}\npacc\n"+outfile+"\n\niter 100\nalfa {alfa:d}\npacc\nvisc\n\nquit\n\" | timeout 20s xvfb-run -a xfoil > /dev/null"
        subprocess.call(xfoil_runstr.format(nnum=nacanum, rnum=visc, alfa=alfa), shell=True)
        with io.open(outfile,'r') as fopen:
            xfoil_out = fopen.readlines()
        return dict(zip(xfoil_out[10].split(),xfoil_out[12].split()))

"""
echo "NACA 2412\nPANE\nOPER\nvisc\n3e6\npacc\ntest.txt\n\nalfa 4\npacc\nvisc\n\nquit\n" | xvfb-run xfoil
"""            

def main():
    xftest = xfoil()
    print(xftest.run_xfoil_naca(3212))
    print(xftest.evaluate([xftest.nlist[3212]]))


# read of the geometry from a data file
if __name__ == "__main__":
    main()
