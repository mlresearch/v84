import numpy as np


class linear_objective:
    def __init__(self, seed=0, d=300):
        """
        Defines a random 300d linear objective.
        :param w (numpy array): linear coefficient.
        :param lower_limits (numpy array): vector of lower limits,
            feasible set is lower_limits < x (componentwise)
        :param upper_limits (numpy array): analogous to lower limit.
        """
        np.random.seed(0)
        self.d = d
        self.w = np.random.randn(d)
        self.lower_limits = -1*np.ones(d)
        self.upper_limits = 1*np.ones(d)

    def bounds(self):
        return [self.lower_limits, self.upper_limits]

    def feasible(self, x):
        feasible_list = []
        for xi in x:
            feasible_list.append(
                np.all((xi > self.lower_limits)*(xi < self.upper_limits))
            )
        return feasible_list

    def evaluate(self, x):
        evaluated_values = []
        evaluated_values = np.dot(np.array(x), self.w)
        assert self.feasible(x)
        # for xi in x:
        # assert self.feasible(xi)
        # evaluated_values.append(np.dot(xi, self.w))
        return evaluated_values


class rand_linquad_obj:
    def __init__(self, seed=0, dim=300, quad_factr=0.1):
        """
        Defines a random 300d quadratic objective.
        :param dim (int): number of dimensions in linear part.
        :param lower_limits (numpy array): vector of lower limits,
            feasible set is lower_limits < x (componentwise)
        :param upper_limits (numpy array): analogous to lower limit.
        """
        np.random.seed(0)
        self.d = dim
        self.w = np.random.randn(dim)
        apart = np.random.randn(dim, dim)
        self.A = np.dot(apart, np.transpose(apart))
        self.A = self.A / np.sqrt(np.linalg.eigvalsh(self.A))*quad_factr
        self.lower_limits = -1*np.ones(dim)
        self.upper_limits = 1*np.ones(dim)

    def bounds(self):
        return [self.lower_limits, self.upper_limits]

    def feasible(self, x):
        feasible_list = []
        for xi in x:
            feasible_list.append(
                np.all((xi > self.lower_limits) * (xi < self.upper_limits))
            )
        return feasible_list

    def evaluate(self, x):
        evaluated_values = []
        for xi in x:
            assert self.feasible(xi)
            evaluated_values.append(
                np.dot(xi, self.w) + np.dot(np.dot(xi, self.A), xi)
            )
        return evaluated_values
