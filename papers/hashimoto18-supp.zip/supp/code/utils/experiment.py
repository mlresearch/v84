from collections import namedtuple
from optimizers.base import optimizer_wrapper
from utils.plots import comparison_container
from utils.logger import logger
from pathos.multiprocessing import ProcessingPool as Pool

Objpack = namedtuple('Objpack', ['objfun', 'batch_size', 'niter'])
Optimpack = namedtuple('Optimpack', ['optfun', 'batch_override', 'plotpar'])


class Experiment:
    def __init__(self, n_replicates, objtype='discrete'):
        self.objfun_dict = {}
        self.optim_dict = {}
        self.objtype = objtype
        self.nreps = n_replicates

    def add_objfun(self, name, objfun, batch_size, niter):
        if self.objtype == 'discrete':
            assert(hasattr(objfun, 'actions'))
        else:
            assert(hasattr(objfun, 'bounds'))
        self.objfun_dict[name] = Objpack(objfun=objfun,
                                         batch_size=batch_size,
                                         niter=niter)

    def add_optim(self, name, optfun, batch_size_override=None,
                  plot_style=None):
        self.optim_dict[name] = Optimpack(optfun=optfun,
                                          batch_override=batch_size_override,
                                          plotpar=plot_style)

    def add_obj_opt(self, obj_list, optim_list):
        for obj in obj_list:
            self.add_objfun(*obj)
        for opt in optim_list:
            self.add_optim(*opt)

    def exec_run(self, args):
        opt_fun, objfun, batch_size, niter, seed = args
        ropt = optimizer_wrapper(opt_fun(),
                                 objfun, batch_size,
                                 niter, seed)
        iterlog = ropt.run_all(debug_level=1)
        return iterlog

    def eval_functions(self, ncpu=1):
        if ncpu > 1:
            p = Pool(ncpu)
        else:
            p = None
        log = logger()
        for objname in self.objfun_dict.keys():
            print('starting:'+objname)
            container = comparison_container(objname, 1)
            objfun, batch_size, niter = self.objfun_dict[objname]
            for opt_name in self.optim_dict.keys():
                print('method:'+opt_name)
                opt_fun, batch_override, plotpar = self.optim_dict[opt_name]
                container.set_plotpar(opt_name, plotpar)
                if batch_override is not None:
                    batch_size = batch_override
                if p is None:
                    for seed in range(self.nreps):
                        iterlog = self.exec_run((opt_fun, objfun, batch_size, niter, seed))
                        container.add_log(opt_name, iterlog)
                else:
                    args = [(opt_fun, objfun, batch_size, niter, seed)
                            for seed in range(self.nreps)]
                    loglist = p.map(self.exec_run, args)
                    for iterlog in loglist:
                        container.add_log(opt_name, iterlog)
            log.add_container(objname, container)
        return log

    def plot_log(self, log, color_map, ylabel='Objective value'):
        log.make_all_plots(color_map, ylabel)
        #log.dump_container(container)
        log.write_all_csv()

    def plot_log_mu(self, log, color_map, ylabel='Objective value'):
        log.make_all_plots_mu(color_map, ylabel)
        #log.dump_container(container)
        log.write_all_csv()

