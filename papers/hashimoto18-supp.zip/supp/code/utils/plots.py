# utility plot code
import matplotlib
from collections import defaultdict
matplotlib.use('Agg')
import matplotlib.pyplot as plt # noqa
import matplotlib.cm as cm


class comparison_container:
    def __init__(self, objname, repcount):
        self.method_logs = defaultdict(list)
        self.objfun_name = objname
        self.replicate_count = repcount
        self.plot_pars = {}

    def add_log(self, name, log):
        self.method_logs[name].append(log)

    def set_plotpar(self, name, par):
        self.plot_pars[name] = par


def plot_comparison(comparison_input, ypack, path, color_map, y_label):
    plt.figure(figsize=(6.0, 4.5))
    for i, method_name in enumerate(comparison_input.method_logs.keys()):
        yval, ylower, yupper = ypack[method_name]
        ppar = comparison_input.plot_pars[method_name]
        if ppar is None:
            plt.plot(range(len(yval)),
                     yval,
                     label=method_name,
                     color=color_map[method_name])
            plt.fill_between(range(len(yval)),
                             yval-ylower,
                             yval+yupper,
                             color=color_map[method_name],
                             alpha=0.2)
        else:
            plt.errorbar(range(len(yval)),
                         yval,
                         yerr=[ylower, yupper], **ppar)
    plt.legend(loc='best')
    plt.title(comparison_input.objfun_name)
    plt.xlabel('Batch')
    plt.ylabel(y_label)
    plt.tight_layout()
    plt.savefig(path+'/'+comparison_input.objfun_name)

def plot_paircompare(comparison_input, ypack, path, color_map, y_label):
    plt.figure(figsize=(6.0, 4.5))
    for i, method_name in enumerate(sorted(comparison_input.method_logs.keys())):
        yval, _ , _ = ypack[method_name]
        ppar = comparison_input.plot_pars[method_name]
        plt.plot(range(len(yval)),
                 yval,
                 label=method_name,
                 color=color_map[method_name])
    plt.legend(loc='best')
    plt.title(comparison_input.objfun_name)
    plt.xlabel('Batch')
    plt.ylabel(y_label)
    plt.tight_layout()
    plt.savefig(path+'/'+comparison_input.objfun_name)
    
