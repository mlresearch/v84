from utils.plots import plot_comparison, plot_paircompare
import os
import pickle
import io
import pandas as pd
import numpy as np
import datetime


def mad(data, axis=None):
    return np.median(np.abs(data - np.median(data, axis)), axis)


def unroll_log_fv(method_log):
    fv_mat = []
    for replicate in method_log:
        minlist = [np.min(np.array(log.eval_fvs)) for log in replicate]
        fv_mat.append([min(minlist[:(i+1)]) for i in range(len(minlist))])
    fv_mat = np.array(fv_mat)
    pct = np.percentile(fv_mat, [25.0, 50.0, 75.0], axis=0)
    return pct[1], pct[1]-pct[0], pct[2]-pct[1]


def unroll_log_mu(method_log):
    fv_mat = []
    for replicate in method_log:
        minlist = [np.min(np.array(log.eval_fvs)) for log in replicate]
        fv_mat.append([min(minlist[:(i+1)]) for i in range(len(minlist))])
    fv_mat = np.array(fv_mat)
    pct = np.mean(fv_mat, axis=0)
    return pct, None, None


def get_timestamp():
    return datetime.datetime.now().strftime('%y%m%d_%H%M%S')


class logger:
    def __init__(self):
        self.start_timestamp = get_timestamp()
        self.output_dir = 'outputs/'+self.start_timestamp
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)
        else:
            Warning('output directory exists: could be a race condition.')
        self.container_dict = {}

    def add_container(self, name, container):
        self.container_dict[name] = container

    def get_ypack(self, container):
        ypack = {}
        for method_name in container.method_logs.keys():
            loglist = container.method_logs[method_name]
            yval, ylower, yupper = unroll_log_fv(loglist)
            ypack[method_name] = (yval, ylower, yupper)
        return ypack

    def get_ypack_mu(self, container):
        ypack = {}
        for method_name in container.method_logs.keys():
            loglist = container.method_logs[method_name]
            yval, ylower, yupper = unroll_log_mu(loglist)
            ypack[method_name] = (yval, ylower, yupper)
        return ypack

    def get_runtimes(self, container):
        runtime_dicts = {}
        for method_name in container.method_logs.keys():
            loglist = container.method_logs[method_name]
            runtime_rep = []
            for replicate in loglist:
                alltime = sum([log.batch_time + log.update_time
                               for log in replicate])
                runtime_rep.append(alltime)
            runmean = sum(runtime_rep) / float(len(runtime_rep))
            runtime_dicts[method_name] = runmean
        return runtime_dicts

    def write_all_csv(self):
        all_method_names = self.container_dict[
            self.container_dict.keys()[0]].method_logs.keys()
        yval_matrix = []
        yerr_matrix = []
        r_matrix = []
        for objname in self.container_dict.keys():
            sub_cont = self.container_dict[objname]
            ypack = self.get_ypack(sub_cont)
            rdict = self.get_runtimes(sub_cont)
            yv_tmp = []
            ye_tmp = []
            r_tmp = []
            for method_name in all_method_names:
                yval, ylower, yupper = ypack[method_name]
                yerr = ylower+yupper
                r_tmp.append(rdict[method_name])
                yv_tmp.append(yval[-1])
                ye_tmp.append(yerr[-1])
            yval_matrix.append(yv_tmp)
            yerr_matrix.append(ye_tmp)
            r_matrix.append(r_tmp)
        row_headers = self.container_dict.keys()
        col_headers = all_method_names
        yv_pd = pd.DataFrame(yval_matrix, row_headers, col_headers)
        ye_pd = pd.DataFrame(yerr_matrix, row_headers, col_headers)
        r_pd = pd.DataFrame(r_matrix, row_headers, col_headers)
        yv_pd.to_csv(self.output_dir+'/yval.csv')
        ye_pd.to_csv(self.output_dir+'/yerr.csv')
        r_pd.to_csv(self.output_dir+'/runtimes.csv')

    def make_all_plots(self, color_map, y_label):
        for objname in self.container_dict.keys():
            self.make_plot(self.container_dict[objname], color_map, y_label)

    def make_all_plots_mu(self, color_map, y_label):
        for objname in self.container_dict.keys():
            self.make_plot_mu(self.container_dict[objname], color_map, y_label)

    def make_plot_mu(self, container, color_map, y_label):
        plot_paircompare(container, self.get_ypack_mu(container), self.output_dir, color_map, y_label)

    def make_plot(self, container, color_map, y_label):
        plot_comparison(container, self.get_ypack(container), self.output_dir, color_map, y_label)

    def dump_container(self, container):
        pickle_path = os.path.join(self.output_dir,
                                   container.objfun_name + '.obj')
        with io.open(pickle_path, 'wb') as fopen:
            pickle.dump(container, fopen, protocol=pickle.HIGHEST_PROTOCOL)
