import numpy as np


def sample_box(n, bounds):
    return np.array([np.random.uniform(low=bounds[0],
                                       high=bounds[1])
                     for i in range(n)])


def sample_jitter(orig, n, bounds, jitter):
    int_ind = np.random.randint(orig.shape[0], size=n)
    scaler = (np.array(bounds[1])
              - np.array(bounds[0])).reshape(1, orig.shape[1])
    cands = orig[int_ind] + np.random.randn(n, orig.shape[1])*jitter*scaler
    for i in range(n):
        cands[i][cands[i] < bounds[0]] = bounds[0][cands[i] < bounds[0]]
        cands[i][cands[i] > bounds[1]] = bounds[1][cands[i] > bounds[1]]
    return cands
