from utils.experiment import Experiment
from functions.PBM import pbm_experiment
from functions.base import all_cont_functions, linear_cont_functions
from functions.aeroxfoil import xfoil
from optimizers.base import random_discrete_optimizer, random_optimizer
from optimizers.bayesopt import discrete_gp_optimizer, gp_optimizer
from optimizers.seqclass import discrete_classify_optimizer, continuous_classify_optimizer, comparison_classify_optimizer
from optimizers.cmaes import cma_optimizer
from matplotlib.colors import hsv_to_rgb

color_map = {'random':'C0',
             'random-2x':'C1',
             'classify-RF':'C2',
             'classify-tuned':'C3',
             'GP':'C4',
             'CMA-ES':'C5',
             'classify-pairwise':'C6',
             'classify-direct':'C7',
             'classify-ensemble':'C8'}
             


def run_linear_probs(nreps=10, ncpu=1):
    obj_list = [[fname, objfun(), 1000, 10]
                for fname, objfun in linear_cont_functions.items()]
    def rfclass():
        return continuous_classify_optimizer(classifier_spec='randforest')
    def linclass():
        return continuous_classify_optimizer(classifier_spec='linear')
    optim_list = [['random', random_optimizer],
                  ['classify-RF', rfclass],
                  ['classify-tuned', linclass],
                  ['GP', gp_optimizer],
                  ['random-2x', random_optimizer, 2000],
                  ['CMA-ES', cma_optimizer]]
    toy_test = Experiment(nreps, objtype='continuous')
    toy_test.add_obj_opt(obj_list, optim_list)
    log = toy_test.eval_functions(ncpu=ncpu)
    toy_test.plot_log(log, color_map)


def run_toyprob(nreps=10, ncpu=1):
    obj_list = [[fname, objfun(), 500, 10]
                for fname, objfun in all_cont_functions.items()[0:2]]
    optim_list = [['random', random_optimizer],
                  ['classify-RF', continuous_classify_optimizer],
                  ['GP', gp_optimizer],
                  ['random-2x', random_optimizer, 1000],
                  ['CMA-ES', cma_optimizer]]
    toy_test = Experiment(nreps, objtype='continuous')
    toy_test.add_obj_opt(obj_list, optim_list)
    log = toy_test.eval_functions(ncpu=ncpu)
    toy_test.plot_log(log, color_map)


def run_pbm(nreps=10, nexpt=10, ncpu=1):
    obj_list = [[pbm_experiment(seed).pbm_name, pbm_experiment(seed), 100, 10]
                for seed in range(nexpt)]
    def pbmclass():
        return discrete_classify_optimizer(classifier_spec='naive_bayes')
    optim_list = [['random', random_discrete_optimizer],
                  ['classify-RF', discrete_classify_optimizer],
                  #['classify-tuned', pbmclass],
                  ['random-2x', random_discrete_optimizer, 200],
                  ['GP', discrete_gp_optimizer]]
    pbm_test = Experiment(nreps, objtype='discrete')
    pbm_test.add_obj_opt(obj_list, optim_list)
    log = pbm_test.eval_functions(ncpu=ncpu)
    pbm_test.plot_log(log, color_map)


def test_aero(nreps=10, ncpu=1):
    obj_list = [['Airfoil design', xfoil(), 30, 10]]
    def aeroclass():
        return discrete_classify_optimizer(classifier_spec='aero')
    optim_list = [['classify-RF', discrete_classify_optimizer],
                  ['classify-tuned', aeroclass],
                  ['random', random_discrete_optimizer],
                  ['random-2x', random_discrete_optimizer, 60],
                  ['GP', discrete_gp_optimizer]]
    aero_test = Experiment(nreps, objtype='discrete')
    aero_test.add_obj_opt(obj_list, optim_list)
    log = aero_test.eval_functions(ncpu=ncpu)
    aero_test.plot_log(log, color_map)

def compare_ensemble(nreps=10, nexpt=10, ncpu=1):
    base_discrete_optimizer = lambda: discrete_classify_optimizer(classifier_spec='linear')
    cv_discrete_optimizer = lambda: discrete_classify_optimizer(classifier_spec='ensembled_linear')
    obj_list = [[pbm_experiment(seed).pbm_name, pbm_experiment(seed), 100, 10]
                for seed in range(nexpt)]
    optim_list = [['random', random_discrete_optimizer],
                  ['classify-direct', base_discrete_optimizer],
                  ['classify-ensemble', cv_discrete_optimizer]]
    pbm_test = Experiment(nreps, objtype='discrete')
    pbm_test.add_obj_opt(obj_list, optim_list)
    log = pbm_test.eval_functions(ncpu=ncpu)
    pbm_test.plot_log(log, color_map)

def compare_pairwise(nreps=10, nexpt=10, ncpu=1):
    base_discrete_optimizer = lambda: discrete_classify_optimizer(
        classifier_spec='ensembled_linear')
    pairwise_factory = lambda factr: \
                       lambda: comparison_classify_optimizer(factr=factr,
                                                             classifier_spec='ensembled_linear')
    obj_list = [[pbm_experiment(seed).pbm_name, pbm_experiment(seed), 500, 10]
                for seed in range(nexpt)]
    optim_list = [['random', random_discrete_optimizer],
                  ['full observation', base_discrete_optimizer],
                  ['c= 5', pairwise_factory(5)],
                  ['c=10', pairwise_factory(10)],
                  ['c=20', pairwise_factory(20)],
                  ['c=50', pairwise_factory(50)]]
    pcmap = {'random':'C0',
             'full observation':'C3',
             'c= 5':'lightsalmon',
             'c=10':'salmon',
             'c=20':'tomato',
             'c=50':'orangered'}
    pbm_test = Experiment(nreps, objtype='discrete')
    pbm_test.add_obj_opt(obj_list, optim_list)
    log = pbm_test.eval_functions(ncpu=ncpu)
    pbm_test.plot_log_mu(log, pcmap)


def main():
    nreps = 15
    ncpu = 15
    run_toyprob(nreps, ncpu=ncpu)
    run_linear_probs(nreps, ncpu=ncpu)
    run_pbm(nreps=nreps, nexpt=20, ncpu=1)
    test_aero(nreps=nreps, ncpu=ncpu)
    compare_ensemble(nreps=nreps, nexpt=1, ncpu=1)
    compare_pairwise(nreps=30, nexpt=1, ncpu=ncpu)


if __name__ == "__main__":
    main()

