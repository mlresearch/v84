"""
Test / example code to check accuracy of the model.
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot
from functions.aero import airfoil_discrete, Airfoil
from functions.aeroxfoil import xfoil
from optimizers.base import random_discrete_optimizer, optimizer_wrapper
from optimizers.bayesopt import discrete_gp_optimizer
from optimizers.seqclass import discrete_classify_optimizer
from utils.plots import comparison_container
from utils.logger import logger

seed = 0
num_replicates = 2
opt_dict = {'random': random_discrete_optimizer,
            'basic_classifier': discrete_classify_optimizer,
            'gp': discrete_gp_optimizer}

"""
log = logger()
print('starting: airfoil simulations')
objfun = airfoil_discrete()
container = comparison_container('airfoil', 1)
for opt_name in opt_dict.keys():
    print('method:'+opt_name)
    for seed in range(num_replicates):
        if opt_name=='cv_weighted_discrete_classifier':
            ropt = optimizer_wrapper(opt_dict[opt_name](),
                                     objfun, 20, 10, seed,
                                     classifier='cv_weightedforest')
        else:
            ropt = optimizer_wrapper(opt_dict[opt_name](),
                                     objfun, 20, 10, seed)
        iterlog = ropt.run_all(debug_level=1)
        container.add_log(opt_name, iterlog)
log.dump_container(container)

for opt_name in opt_dict.keys():
    iterlogs = container.method_logs[opt_name][0]
    lastlog = iterlogs[-1]
    minpoint = lastlog.eval_points[np.argmin(lastlog.eval_fvs)]
    best_airfoil = Airfoil(objfun.nx, minpoint)
    best_airfoil.set_freestream(1, 5.0)
    best_airfoil.simulate_airflow()
    best_airfoil.plot_all()
    pyplot.savefig(log.output_dir+'/'+opt_name+'_airfoil.png')
"""

log = logger()
print('starting: xfoil simulations')
objfun = xfoil()
container = comparison_container('airfoil', 1)
for opt_name in opt_dict.keys():
    print('method:'+opt_name)
    for seed in range(num_replicates):
        ropt = optimizer_wrapper(opt_dict[opt_name](),
                                 objfun, 20, 10, seed)
        iterlog = ropt.run_all(debug_level=1)
        container.add_log(opt_name, iterlog)
log.dump_container(container)

