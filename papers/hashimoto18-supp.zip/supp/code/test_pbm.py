"""
Test / example code to check accuracy of the model.
"""

import matplotlib
matplotlib.use('Agg')
from functions.PBM import pbm_experiment
from optimizers.base import random_discrete_optimizer, optimizer_wrapper
from optimizers.bayesopt import discrete_gp_optimizer
from optimizers.seqclass import discrete_classify_optimizer, comparison_classify_optimizer
from utils.plots import comparison_container
from utils.logger import logger


base_discrete_optimizer = lambda: discrete_classify_optimizer(classifier_spec='linear')
cv_discrete_optimizer = lambda: discrete_classify_optimizer(classifier_spec='ensembled_linear')
cv_comparison_optimizer = lambda: comparison_classify_optimizer(classifier_spec='ensembled_linear')
opt_dict = {
    'random': random_discrete_optimizer,
    #'gp': discrete_gp_optimizer,
    'discrete_classifier': base_discrete_optimizer,
    'cv_weighted_discrete_classifier': cv_discrete_optimizer,
    'comparison_classifier': cv_comparison_optimizer
}

seed = 0
num_replicates = 5
batch_size = 300
num_rounds = 30

log = logger()
for function_seed in range(10):
    objfun = pbm_experiment(function_seed)
    objname = 'pbm_experiment_'+objfun.pbm_name
    print('starting:'+objname)
    container = comparison_container(objname, 1)
    for opt_name in opt_dict.keys():
        print('method:'+opt_name)
        for seed in range(num_replicates):
            ropt = optimizer_wrapper(opt_dict[opt_name](),
                                     objfun, batch_size, num_rounds, seed)
            iterlog = ropt.run_all(debug_level=2)
            container.add_log(opt_name, iterlog)
    log.dump_container(container)

