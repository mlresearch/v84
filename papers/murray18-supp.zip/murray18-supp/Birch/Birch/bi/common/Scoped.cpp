/**
 * @file
 */
#include "bi/common/Scoped.hpp"

bi::Scoped::Scoped(Scope* scope) : scope(scope) {
  //
}

bi::Scoped::~Scoped() {
  //
}
