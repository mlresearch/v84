/**
 * @file
 */
#include "bi/common/ReturnTyped.hpp"

bi::ReturnTyped::ReturnTyped(Type* returnType) :
    returnType(returnType) {
  //
}

bi::ReturnTyped::~ReturnTyped() {
  //
}
