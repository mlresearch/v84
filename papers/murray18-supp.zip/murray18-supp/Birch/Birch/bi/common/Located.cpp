/**
 * @file
 */
#include "bi/common/Located.hpp"

bi::Located::Located(Location* loc) :
    loc(loc) {
  //
}

bi::Located::~Located() {
  //
}
