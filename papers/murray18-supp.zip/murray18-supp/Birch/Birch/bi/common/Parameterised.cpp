/**
 * @file
 */
#include "bi/common/Parameterised.hpp"

bi::Parameterised::Parameterised(Expression* params) :
    params(params) {
  //
}

bi::Parameterised::~Parameterised() {
  //
}
