/**
 * @file
 */
#include "bi/common/Based.hpp"

bi::Based::Based(Type* base) :
    base(base) {
  //
}

bi::Based::~Based() {
  //
}
