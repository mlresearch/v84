/**
 * @file
 */
#include "bi/common/Valued.hpp"

bi::Valued::Valued(Expression* value) : value(value) {
  //
}

bi::Valued::~Valued() {
  //
}
