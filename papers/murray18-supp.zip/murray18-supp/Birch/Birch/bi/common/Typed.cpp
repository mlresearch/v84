/**
 * @file
 */
#include "bi/common/Typed.hpp"

bi::Typed::Typed(Type* type) :
    type(type) {
  //
}

bi::Typed::~Typed() {
  //
}
