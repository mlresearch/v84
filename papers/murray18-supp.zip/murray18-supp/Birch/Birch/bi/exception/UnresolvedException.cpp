/**
 * @file
 */
#include "bi/exception/UnresolvedException.hpp"
