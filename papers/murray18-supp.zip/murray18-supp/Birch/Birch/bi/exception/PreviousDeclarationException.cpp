/**
 * @file
 */
#include "bi/exception/PreviousDeclarationException.hpp"
