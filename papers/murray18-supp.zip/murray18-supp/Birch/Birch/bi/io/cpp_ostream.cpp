/**
 * @file
 */
#include "bi/io/cpp_ostream.hpp"
