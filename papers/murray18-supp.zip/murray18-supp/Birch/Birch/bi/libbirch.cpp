/**
 * @file
 */
extern "C" int bi_present() {
  return 0;
}
