name: Untitled
version: 0.0.0
---

# Untitled (package for Birch)

## Installation

To build, use:

    birch build
    
To install system wide, use:

    birch install


## Version history

### v0.0.0

* Initialised project.
