## Install

To run the examples, it is necessary to install the Birch compiler and the Birch standard library, then compile the examples.

Birch requires the Boost libraries and Eigen linear algebra library. These should be installed first. The first `configure` script will check for these dependencies and a compatible build system.

To install the Birch compiler, run the following from within the `Birch` directory:

    ./configure
    make
    make install
    
To install the Birch standard library, run the following from within the `Birch.Standard` directory:

    birch build
    birch install
    
To compiler the examples, run the following from within the `Birch.Example` directory:

    birch build

The vector-borne disease example is in a separate `VBD` directory and is built in the same way:

    birch build

## Run

Finally, to run the delayed sampling examples, run any of the following commands from within the `Birch.Example` directory:

    birch delay_triplet
    birch delay_iid
    birch delay_spike_and_slab
    birch delay_kalman
    birch delay_rbpf

The Birch source code for these examples can be found in `Birch.Example/bi/delay`. Further explanation and command-line options can be found in these source files.

Within the `VBD` directory, use:

    birch sample --start-time 63 --end-time 252 --nsamples 10 \
        --nparticles 8192
