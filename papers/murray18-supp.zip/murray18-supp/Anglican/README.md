## Install and run

To install and run Anglican and the examples, do the following:

1. Make sure you have Java 1.6 or greater installed.
2. Install [Leiningen](https://leiningen.org/).
3. In the `anglican` directory, run `lein install`.
4. In the `examples` directory, run `lein gorilla` and open the resulting web address. Here you can find a worksheet `worksheets/delayed_sampling.clj` with all the examples preloaded. You can interactively run the examples in your browser.

The source code for the examples is available in the `examples/programs` folder.
