(ns anglican-user.program
  (:use [anglican emit runtime core]))
