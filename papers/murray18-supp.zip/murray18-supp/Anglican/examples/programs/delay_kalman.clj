(use 'nstools.ns)
(ns+ delay-kalman
     (:like anglican-user.program)
     (:use [anglican core emit runtime delay stat]))

(defquery delay-kalman
  "Demonstrates sampling from a univariate linear-Gaussian state-space
  model"
  [a data]
  (map ds-value

      ; initialize
      (let [x (ds-normal 0 1)]
        (ds-observe (ds-normal x 1) (first data))

        ; transition
        (loop [x x
               data (rest data)
               res [x]]
          (if (seq data)
            (let [x (ds-normal a x 1)]
              (ds-observe (ds-normal x 1) (first data))
              (recur x (rest data) (conj res x)))
            res)))))
