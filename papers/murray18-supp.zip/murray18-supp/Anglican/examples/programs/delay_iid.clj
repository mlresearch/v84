(use 'nstools.ns)
(ns+ delay-iid
     (:like anglican-user.program)
     (:use [anglican core emit runtime delay stat]))

(defquery delay-iid
  [observations]
  "Demonstration of multiple observations in an array, used to estimate a
   single parameter."

  ;; prior
  (let [x (ds-normal 0 1)]

    ;; likelihood
    (loop [observations observations]
      (if (seq observations)
        (do
          (ds-observe (ds-normal x 1) (first observations))
          (recur (rest observations)))

        ;; output
        (ds-value x)))))
