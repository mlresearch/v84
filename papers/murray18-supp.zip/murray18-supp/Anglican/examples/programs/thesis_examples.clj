(use 'nstools.ns)
(ns+ thesis-examples
     (:like anglican-user.program)
     (:use [anglican core emit runtime delay stat]))

;; A simple coin example

(defquery coin
  (let [x (sample (beta 2 2))]
    (observe (bernoulli x) 1)
    x))

(defquery ds-coin
  (let [x (ds-beta 2 2)]
    (ds-observe (ds-bernoulli x) 1)
    (ds-value x)))

;; A coin with a more complex prior

(defquery complex-coin []
  (let [b (sample (bernoulli 0.5))
        x (sample (if (= b 1)
                    (beta 2 2)
                    (uniform-continuous 0 0.5)))]
    (observe (bernoulli x) 1)
    x))

(defquery ds-complex-coin []
  (let [b (sample (bernoulli 0.5))
        x (if (= b 1)
            (ds-beta 2 2)
            (sample (uniform-continuous 0 0.5)))]
    (ds-observe (ds-bernoulli x) 1)
    (ds-value x)))


;; A coin with multiple observations

(defquery coin
  (let [x (sample (beta 2 2))]
    (observe (bernoulli x) 1)
    (observe (bernoulli x) 1)
    (observe (bernoulli x) 0)
    x))

(defquery ds-coin
  (let [x (ds-beta 2 2)]
    (ds-observe (ds-bernoulli x) 1)
    (ds-observe (ds-bernoulli x) 1)
    (ds-observe (ds-bernoulli x) 0)
    (ds-value x)))

;; A chain of normal distributions

(defquery chain
  (let [x (sample (normal 0 1))
        y (sample (normal x 2))]
    (observe (normal y 3) 1.2)
    x))

(defquery ds-chain
  (let [x (ds-normal 0 1)
        y (ds-normal x 2)
        z (ds-normal y 3)]
    (ds-observe z 1.2)
    (ds-value x)))

;; A tree of normal distributions

(defquery chain
  (let [x2 (sample (normal 1.2 2))
        x4 (sample (normal 1.2 4))
        x5 (sample (normal 1.2 5))]
    (observe (normal x2 3) 2.4)
    (observe (normal 0 1) 1.2)
    [1.2 x2 2.4 x4 x5]))

(defquery ds-chain
  (let [x1 (ds-normal 0 1)
        x2 (ds-normal x1 2)
        x3 (ds-normal x2 3)
        x4 (ds-normal x1 4)
        x5 (ds-normal x1 5)]
    (ds-observe x3 2.4)
    (ds-observe x1 1.2)
    (map ds-value [x1 x2 x3 x4 x5])))

;; A linear-Gaussian state-space model

(defquery kalman
  (first
    (let [data [0.4 0.9 -0.1]
          x (sample (normal 0 1))]
      (observe (normal x 1) (first data))
      (loop [x x
             data (rest data)
             res [x]]
        (if (seq data)
          (let [x (sample (normal (* 3 x) 1))]
            (observe (normal x 1) (first data))
            (recur x (rest data) (conj res x)))
          res)))))

(defquery ds-kalman
  (ds-value
    (first
      (let [data [0.4 0.9 -0.1]
            x (ds-normal 0 1)]
        (ds-observe (ds-normal x 1) (first data))
        (loop [x x
               data (rest data)
               res [x]]
          (if (seq data)
            (let [x (ds-normal 3 x 1)]
              (ds-observe (ds-normal x 1) (first data))
              (recur x (rest data) (conj res x)))
            res))))))

