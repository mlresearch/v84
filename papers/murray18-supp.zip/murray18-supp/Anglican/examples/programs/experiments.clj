(use 'nstools.ns)
(ns+ experiments
     (:like anglican-user.program)
     (:use [anglican core emit runtime delay stat]))

;; A simple normal mean relationship used for the experiments

(defquery simple-normal []
  (let [x (sample (normal 0 10))]
    (observe (normal x 1) 20)
    x))

(defquery ds-simple-normal []
  (let [x (ds-normal 0 10)]
    (ds-observe (ds-normal x 1) 20)
    (ds-value x)))

;; A version of the coin with a complex prior belief with multiple
;; observations, used for the experiments

(defquery complex-coin []
  (let [b (sample (bernoulli 0.5))
    	x (sample (if (= b 1)
                    (beta 2 2)
                    (uniform-continuous 0 0.5)))]
    (repeatedly 10 #(observe (bernoulli x) 1))
    x))

(defquery ds-complex-coin []
  (let [b (sample (bernoulli 0.5))
    	x (if (= b 1)
            (ds-beta 2 2)
            (sample (uniform-continuous 0 0.5)))]
    (repeatedly 10 #(ds-observe (ds-bernoulli x) 1))
    (ds-value x)))

;; A Kalman smoother used for the experiments

(defquery kalman [data]
  (first
    (let [x (sample (normal 0 10))]
      (loop [x x
             data data
             res [x]]
        (if (seq data)
          (let [x (sample (normal (+ 2 x) 4))]
            (observe (normal x 1) (first data))
            (recur x (rest data) (conj res x)))
          res)))))

(defquery ds-kalman [data]
  (ds-value
    (first
      (let [x (ds-normal 0 4)]
        (loop [x x
               data data
               res [x]]
          (if (seq data)
            (let [x (ds-normal 1 2 x 4)]
              (ds-observe (ds-normal x 1) (first data))
              (recur x (rest data) (conj res x)))
            res))))))

;; A model in which delayed sampling can yield no improvement
;; (We make the standard deviation the parent instead of the mean
;; in the linear-Gaussian state-space model)

(defquery non-kalman [data]
  (first
    (let [x (sample (normal 0 10))]
      (loop [x x
             data data
             res [x]]
        (if (seq data)
          (let [x (sample (normal 4 (abs x)))]
            (observe (normal 1 (abs x)) (first data))
            (recur x (rest data) (conj res x)))
          res)))))

(defquery ds-non-kalman [data]
  (ds-value
    (first
      (let [x (ds-normal 0 4)]
        (loop [x x
               data data
               res [x]]
          (if (seq data)
            (let [x (ds-normal 4 (abs (ds-value x)))]
              (ds-observe (ds-normal 1 (abs (ds-value x))) (first data))
              (recur x (rest data) (conj res x)))
            res))))))

;; Run a time experiment and print the execution time

(defn run-time-experiment [n alg query value name]
  (println name ": ")
  (time (doall (take n (doquery alg query value))))
  nil)

;; Run an mse-experiment and write the output to filename

(defn run-mse-experiment [n reps alg query value filename]
  (dotimes [r reps]
    (let [samples (take n (doquery alg query value))
          data
          (map (fn [i]
                 (str i "\t"
                      (empirical-mean
                        (collect-results
                          (take i samples))) "\n"))
               (range 1 (+ n 1)))]
      (spit (str filename "_" r ".dat")
            (str "samples\testimate\n"
                 (apply str data))))))

;; Run the experiments

(defn experiment []
  (run-mse-experiment 1000 10 :importance simple-normal []
                      "../doc/data/simple_normal")
  (run-mse-experiment 1000 10 :importance ds-simple-normal []
                      "../doc/data/ds_simple_normal")
  (run-mse-experiment 1000 10 :importance complex-coin []
                      "../doc/data/complex_coin")
  (run-mse-experiment 1000 10 :importance ds-complex-coin []
                      "../doc/data/ds_complex_coin")
  (run-mse-experiment 1000 10 :importance kalman [[4 7 8 11 5]]
                      "../doc/data/kalman")
  (run-mse-experiment 1000 10 :importance ds-kalman [[4 7 8 11 5]]
                      "../doc/data/ds_kalman")
  (run-time-experiment 100000 :importance
                       simple-normal [] "simple-normal")
  (run-time-experiment 100000 :importance
                       ds-simple-normal [] "ds-simple-normal")
  (run-time-experiment 100000 :importance
                       complex-coin [] "complex-coin")
  (run-time-experiment 100000 :importance
                       ds-complex-coin [] "ds-complex-coin")
  (run-time-experiment 100000 :importance
                       kalman [[4 7 8 11 5]] "kalman")
  (run-time-experiment 100000 :importance
                       ds-kalman [[4 7 8 11 5]] "ds-kalman")
  (run-time-experiment 100000 :importance
                       non-kalman [[4 7 8 11 5]] "non-kalman")
  (run-time-experiment 100000 :importance
                       ds-non-kalman [[4 7 8 11 5]] "ds-non-kalman")
  )

