(use 'nstools.ns)
(ns+ delay-spike-and-slab
     (:like anglican-user.program)
     (:use [anglican core emit runtime delay stat]))

(defquery delay-spike-and-slab
  "Demonstrates how delayed sampling can yield to different runtime states
   through a stochastic branch."
  (let [x (sample (bernoulli 0.5))
        y (if (= x 1)
            (ds-normal 0 1)
            0)]
    (if (symbol? y)
      "distribution"
      "value")))
