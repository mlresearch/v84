(use 'nstools.ns)
(ns+ delay-triplet
     (:like anglican-user.program)
     (:use [anglican core emit runtime delay stat]))

(defquery delay-triplet
  "Demonstrates sampling from a triplet of Gaussian random variables,
  where the last one is observed."
  (let [x (ds-normal 0 1)
        y (ds-normal x 1)
        z (ds-normal y 1)]
    (ds-observe z 1.2)
    (map ds-value [x y z])))
