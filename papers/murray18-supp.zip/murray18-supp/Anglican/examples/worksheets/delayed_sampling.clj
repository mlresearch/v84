;; gorilla-repl.fileformat = 1

;; **
;;; #Delayed sampling in Anglican
;; **

;; **
;;; Run this before running any other code!
;; **

;; @@
(ns anglican.worksheet
  (:require [gorilla-plot.core :as plot]
            [clojure.pprint :refer [pprint]])
  (:use [anglican core emit runtime delay stat]))
;; @@

;; **
;;; ##Paper examples
;; **

;; **
;;; ###delay_triplet.clj
;; **

;; @@
(defquery delay-triplet
  "Demonstrates sampling from a triplet of Gaussian random variables,
  where the last one is observed."
  (let [x (ds-normal 0 1)
        y (ds-normal x 1)
        z (ds-normal y 1)]
    (ds-observe z 1.2)
    (map ds-value [x y z])))

(pprint (take 5 (doquery :importance delay-triplet [])))
;; @@

;; **
;;; ###delay_iid.clj
;; **

;; @@
(defquery delay-iid
  [observations]
  "Demonstration of multiple observations in an array, used to estimate a
   single parameter."
  
  ;; prior
  (let [x (ds-normal 0 1)]
   	
    ;; likelihood
    (loop [observations observations]
      (if (seq observations)       
        (do
          (ds-observe (ds-normal x 1) (first observations))
          (recur (rest observations)))
        
        ;; output
        (ds-value x)))))

(pprint (take 5 (doquery :importance delay-iid [[0.1 -0.3 0.7]])))
;; @@

;; **
;;; ###delay_spike_and_slab.clj
;; **

;; @@
(defquery delay-spike-and-slab
  "Demonstrates how delayed sampling can yield to different runtime states
   through a stochastic branch."
  (let [x (sample (bernoulli 0.5))
        y (if (= x 1)
            (ds-normal 0 1)
            0)]
    (if (symbol? y)
      "distribution"
      "value")))
 
(pprint (take 10 (doquery :importance delay-spike-and-slab [])))
;; @@

;; **
;;; ###delay_kalman.clj
;; **

;; @@
(defquery delay-kalman 
  "Demonstrates sampling from a univariate linear-Gaussian state-space
  model"
  [a data]
  (map ds-value
       
      ; initialize
      (let [x (ds-normal 0 1)]
        (ds-observe (ds-normal x 1) (first data))
        
        ; transition
        (loop [x x
               data (rest data)
               res [x]]
          (if (seq data)
            (let [x (ds-normal a x 1)]
              (ds-observe (ds-normal x 1) (first data))
              (recur x (rest data) (conj res x)))
            res)))))

(pprint (take 5 (doquery :importance delay-kalman [3 [0.1 0.2 0.3]])))
;; @@

;; **
;;; ##Thesis examples
;; **

;; **
;;; 
;; **

;; **
;;; ###A simple coin example
;; **

;; **
;;; Anglican:
;; **

;; @@
(defquery coin
  (let [x (sample (beta 2 2))]
    (observe (bernoulli x) 1)
    x))

(pprint (take 5 (doquery :importance coin [])))
;; @@

;; **
;;; Anglican with delayed sampling:
;; **

;; @@
(defquery ds-coin
  (let [x (ds-beta 2 2)]
    (ds-observe (ds-bernoulli x) 1)
    (ds-value x)))

(pprint (take 5 (doquery :importance ds-coin [])))
;; @@

;; **
;;; ###A coin with a more complex prior
;; **

;; **
;;; Anglican:
;; **

;; @@
(defquery complex-coin []
  (let [b (sample (bernoulli 0.5))
        x (sample (if (= b 1)
                    (beta 2 2)
                    (uniform-continuous 0 0.5)))]
    (observe (bernoulli x) 1)
    x))

(pprint (take 5 (doquery :importance complex-coin [])))
;; @@

;; **
;;; Anglican with delayed sampling:
;; **

;; @@
(defquery ds-complex-coin []
  (let [b (sample (bernoulli 0.5))
        x (if (= b 1)
            (ds-beta 2 2)
            (sample (uniform-continuous 0 0.5)))]
    (ds-observe (ds-bernoulli x) 1)
    (ds-value x)))

(pprint (take 5 (doquery :importance ds-complex-coin [])))
;; @@

;; **
;;; ###A coin with multiple observations
;; **

;; **
;;; Anglican:
;; **

;; @@
(defquery coin
  (let [x (sample (beta 2 2))]
    (observe (bernoulli x) 1)
    (observe (bernoulli x) 1)
    (observe (bernoulli x) 0)
    x))

(pprint (take 5 (doquery :importance coin [])))
;; @@

;; **
;;; Anglican with delayed sampling:
;; **

;; @@
(defquery ds-coin
  (let [x (ds-beta 2 2)]
    (ds-observe (ds-bernoulli x) 1)
    (ds-observe (ds-bernoulli x) 1)
    (ds-observe (ds-bernoulli x) 0)
    (ds-value x)))

(pprint (take 5 (doquery :importance ds-coin [])))
;; @@

;; **
;;; ###A chain of normal distributions
;; **

;; **
;;; Anglican:
;; **

;; @@
(defquery chain
  (let [x (sample (normal 0 1))
        y (sample (normal x 2))]
    (observe (normal y 3) 1.2)
    x))

(pprint (take 5 (doquery :importance chain [])))
;; @@

;; **
;;; Anglican with delayed sampling:
;; **

;; @@
(defquery ds-chain
  (let [x (ds-normal 0 1)
        y (ds-normal x 2)
        z (ds-normal y 3)]
    (ds-observe z 1.2)
    (ds-value x)))

(pprint (take 5 (doquery :importance ds-chain [])))
;; @@

;; **
;;; ###A tree of normal distributions
;; **

;; **
;;; Anglican:
;; **

;; @@
(defquery chain
  (let [x2 (sample (normal 1.2 2))
        x4 (sample (normal 1.2 4))
        x5 (sample (normal 1.2 5))]
    (observe (normal x2 3) 2.4)
	(observe (normal 0 1) 1.2)
    [1.2 x2 2.4 x4 x5]))

(pprint (take 5 (doquery :importance chain [])))
;; @@

;; **
;;; Anglican with delayed sampling:
;; **

;; @@
(defquery ds-chain
  (let [x1 (ds-normal 0 1)
        x2 (ds-normal x1 2)
        x3 (ds-normal x2 3)
        x4 (ds-normal x1 4)
        x5 (ds-normal x1 5)]
    (ds-observe x3 2.4)
    (ds-observe x1 1.2)
    (map ds-value [x1 x2 x3 x4 x5])))

(pprint (take 5 (doquery :importance ds-chain [])))
;; @@

;; **
;;; ###A linear-Gaussian state-space model
;; **

;; **
;;; Anglican:
;; **

;; @@
(defquery kalman
  (first
    (let [data [0.4 0.9 -0.1]
          x (sample (normal 0 1))]
      (observe (normal x 1) (first data))
      (loop [x x
             data (rest data)
             res [x]]
        (if (seq data)
          (let [x (sample (normal (* 3 x) 1))]
            (observe (normal x 1) (first data))
            (recur x (rest data) (conj res x)))
          res)))))

(pprint (take 5 (doquery :importance kalman [])))
;; @@

;; **
;;; Anglican with delayed sampling:
;; **

;; @@
(defquery ds-kalman
  (ds-value
    (first
      (let [data [0.4 0.9 -0.1]
            x (ds-normal 0 1)]
        (ds-observe (ds-normal x 1) (first data))
        (loop [x x
               data (rest data)
               res [x]]
          (if (seq data)
            (let [x (ds-normal 3 x 1)]
              (ds-observe (ds-normal x 1) (first data))
              (recur x (rest data) (conj res x)))
            res))))))

(pprint (take 5 (doquery :importance ds-kalman [])))
;; @@
